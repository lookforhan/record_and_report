clear;close all;clc;tic;
input_name='YZnetYS.inp';
loadlibrary('epanet2.dll','epanet2.h');%����EPA��̬���ӿ�
calllib('epanet2','ENopen',input_name,'YZnetYS.rpt','YZnetYS.out');%�򿪰�������
pointer_1=libpointer('singlePtr',0);% ָ�����
pointer_2=libpointer('int32Ptr',0);% ָ�����
[~,link_num]=calllib('epanet2','ENgetcount',2,pointer_2);% ��ùܶ���Ŀ
[~,Node_num]=calllib('epanet2','ENgetcount',0,pointer_2);% ��ýڵ���Ŀ
calllib('epanet2','ENsettimeparam',0,86400);%ģ����ʱ24h=86400s
calllib('epanet2','ENopenH');
calllib('epanet2','ENinitH',1);
tstep=0;temp_tstep=0; %����������
while tstep<86400   
[~,tstep]=calllib('epanet2','ENrunH',tstep);
[errcode,temp_tstep]=calllib('epanet2','ENnextH',temp_tstep);%
end
calllib('epanet2','ENcloseH');
calllib('epanet2','ENsaveH');
calllib('epanet2','ENsetreport','NODES ALL'); 
calllib('epanet2','ENsetreport','LINKS ALL'); 
calllib('epanet2','ENreport'); %������㱨��
calllib('epanet2','ENclose'); %�رռ���
unloadlibrary epanet2;%ж��epanet2.dll
value=[];
fid=fopen('YZnetYS.out','r');
binfile='YZnetYS.out';
if fid~=-1
data = fread(fid,'int32');
fclose(fid);
value.BinNumberReportingPeriods = data(end-2);
clear data;
fid1 = fopen(binfile, 'r');
fseek(fid1, 0, 'bof');
value.Binmagicnumber=fread(fid1, 1, 'uint32');
value.BinLibEPANET=fread(fid1, 1, 'uint32');
value.BinNumberNodes=fread(fid1, 1, 'uint32');
value.BinNumberReservoirsTanks=fread(fid1, 1, 'uint32');
value.BinNumberLinks=fread(fid1, 1, 'uint32');
value.BinNumberPumps=fread(fid1, 1, 'uint32');
value.BinNumberValves=fread(fid1, 1, 'uint32');
value.BinWaterQualityOption=fread(fid1, 1, 'uint32');
value.BinIndexNodeSourceTracing=fread(fid1, 1, 'uint32');
value.BinFlowUnitsOption=fread(fid1, 1, 'uint32');
value.BinPressureUnitsOption=fread(fid1, 1, 'uint32');
value.BinTimeStatisticsFlag=fread(fid1, 1, 'uint32');
value.BinReportingStartTimeSec=fread(fid1, 1, 'uint32');
value.BinReportingTimeStepSec=fread(fid1, 1, 'uint32');
value.BinSimulationDurationSec=fread(fid1, 1, 'uint32');
value.BinProblemTitle1=fread(fid1, 80, '*char')';
value.BinProblemTitle2=fread(fid1, 80, '*char')';
value.BinProblemTitle3=fread(fid1, 80, '*char')';
value.BinNameInputFile=fread(fid1, 260, '*char')';
value.BinNameReportFile=fread(fid1, 260, '*char')';
value.BinNameChemical=fread(fid1, 32, '*char')';
value.BinChemicalConcentrationUnits=fread(fid1, 16, '*char')'; 
fread(fid1, 4, '*char');
for i=1:value.BinNumberNodes
value.BinIDLabelEachNode{i}=fread(fid1, 32, '*char')'; % error NODES*32
value.BinIDLabelEachNode{i}=value.BinIDLabelEachNode{i}(find(value.BinIDLabelEachNode{i}));
end
for i=1:value.BinNumberLinks
value.BinIDLabelEachLink{i}=fread(fid1, 32, '*char')';  % error LINKS*32
value.BinIDLabelEachLink{i}=value.BinIDLabelEachLink{i}(find(value.BinIDLabelEachLink{i}));
end
fread(fid1, [3,4], '*char');
value.BinIndexStartNodeEachLink=fread(fid1, value.BinNumberLinks, 'uint32')';
value.BinIndexEndNodeEachLink=fread(fid1, value.BinNumberLinks, 'uint32')';
value.BinTypeCodeEachLink=fread(fid1, value.BinNumberLinks, 'uint32')';
value.BinNodeIndexEachReservoirsTank=fread(fid1, value.BinNumberReservoirsTanks, 'uint32')'; % error
value.BinCrossSectionalAreaEachTank=fread(fid1,value.BinNumberReservoirsTanks, 'float')';
value.BinElevationEachNode=fread(fid1,value.BinNumberNodes, 'float')';
value.BinLengthEachLink=fread(fid1, value.BinNumberLinks, 'float')';
value.BinDiameterEachLink=fread(fid1, value.BinNumberLinks, 'float')';

value.BinPumpIndexListLinks=fread(fid1, value.BinNumberPumps, 'float')';
value.BinPumpUtilization=fread(fid1, value.BinNumberPumps, 'float')';
value.BinAverageEfficiency=fread(fid1, value.BinNumberPumps, 'float')';
value.BinAverageKwattsOrMillionGallons=fread(fid1, value.BinNumberPumps, 'float')';
value.BinAverageKwatts=fread(fid1, value.BinNumberPumps, 'float')';
value.BinPeakKwatts=fread(fid1, value.BinNumberPumps, 'float')';
value.BinAverageCostPerDay=fread(fid1, value.BinNumberPumps, 'float')';

fread(fid1, 1, 'float');

for i=1:value.BinNumberReportingPeriods
value.BinnodeDemand(:,i)         = fread(fid1, value.BinNumberNodes, 'float')';
value.BinnodeHead(:,i)           = fread(fid1, value.BinNumberNodes, 'float')';
value.BinnodePressure(:,i)       = fread(fid1, value.BinNumberNodes, 'float')';
value.BinnodeQuality(:,i)        = fread(fid1, value.BinNumberNodes, 'float')';
value.BinlinkFlow(:,i)           = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkVelocity(:,i)       = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkHeadloss(:,i)       = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkQuality(:,i)        = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkStatus(:,i)         = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkSetting(:,i)        = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkReactionRate(:,i)   = fread(fid1, value.BinNumberLinks, 'float')';
value.BinlinkFrictionFactor(:,i) = fread(fid1, value.BinNumberLinks, 'float')';
end
value.BinAverageBulkReactionRate=fread(fid1, 1, 'float')';
value.BinAverageWallReactionRate=fread(fid1, 1, 'float')';
value.BinAverageTankReactionRate=fread(fid1, 1, 'float')';
value.BinAverageSourceInflowRate=fread(fid1, 1, 'float')';
value.BinNumberReportingPeriods2=fread(fid1, 1, 'uint32')';
value.BinWarningFlag=fread(fid1, 1, 'uint32')';
value.BinMagicNumber=fread(fid1, 1, 'uint32')';
fclose(fid1);
end
if fid==-1
fprintf('"Run was unsuccessful."\n');
else
fprintf('"Run was successful."\n');
end
toc;

