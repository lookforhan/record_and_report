%12���������ս������ɿ��ԣ�
%�����Ҫ�������� 

function Dodecahedron
clear all,clc
rand('state',0);%MATLAB�����������
randn('state',0);%MATLAB�����������
disp(sprintf('*****���ڼ���*****'));
timestamp ( )
global GRAPH
E=[1,1,1,2,2,3,3,4,4, 5, 5, 6,6, 7, 8,8, 9, 10,11,11,12,13,13,14,15,15,16,17,18,19;
   2,3,4,5,6,7,8,9,10,10,11,7,12,13,9,14,15,16,12,17,18,14,18,19,16,19,17,20,20,20]';%[30,2]
GRAPH.E=E; %E: [30x2 double],create structure field name 'E' to store matrix E
%x=rand(1,30);%30�������,generate some random times
%Sx=S(x);%�ṹ����Sx=0.4565,call function S(x)
% the matrix E is assumed to be loaded into the workspace
m=size(E,1);%m=30, 
p=ones(m,3)*(1-0.1^3);%p=ones(m,3)*(1-0.1^3),3��30��
% list the edges comprising the paths
paths{1}=[1 4 11 20 28];%[1x5 double]
paths{2}=[3 8 17 26 30];
paths{3}=[2 6 14 23 29];
ell_U=1; % compute normalizing constant
for i=1:size(paths,2)%1:3
    P=paths{i};%����·��
    ell_U=ell_U*(1-prod(p(P)));
end
% compute estimator
N=10^5; %ģ�����
ell=nan(N,1);
for i=1:N
    x=f_bar(p,paths);%��Ҫ�����ܶȺ�������,
    ell(i)=(S(x)>1)*ell_U;
end
[mean(ell), std(ell)/mean(ell)/sqrt(N)];
UR=mean(ell);
RE=100*std(ell)/mean(ell)/sqrt(N);
disp(sprintf('ģ�����=%e  ���ɿ��ȹ���=%e  ������=%f��\n',N,UR,RE));
timestamp ( )
disp(sprintf('**********�������**********'));

function x=f_bar(p,paths)%��Ҫ�����ܶȺ�������
% implements sampling from f_bar
% p is a vector with the corresponding reliabilities
% 'paths' is a cell array of edges describing the paths;
%step 7 and 8
m=length(p);x=zeros(1,m); p=p(:)';
for j=1:size(paths,2)
    P=paths{j}; % paths have to be disjoint!
    x(P)=path_sampling(p(P));%·������
end
idx=find(x==0); % find the edges that are not on the paths
% sample edges not belonging to the paths
x(idx)=-log(rand(1,length(idx)))./(-log(1-p(idx)));

function Y=path_sampling(p_bar)%·������
%samples the repair times that belong to the paths
k=length(p_bar);
% step 2
P=cumprod(p_bar);
p_star=(1-p_bar).*[1,P(1:end-1)];
p_star=p_star/(1-P(end));
% step 3
[dummy,idx]=histc(rand,[0,cumsum(p_star)]);
% step 4
lam=-log(1-p_bar); %exponential rates
for i=1:idx-1
    Y(i)=expt(lam(i),0,1);   
end
% step 5
Y(idx)=1-log(rand)/lam(idx);
% step 6
for i=idx+1:k
    Y(i)= -log(rand)/lam(i);
end

function [Sx,b,perm]=S(X) %����ṹ����
% Computes the (possibly random) time at which a network becomes
% operational given the (random) times of repair X
% Inputs:  X    - a configuration of times of repair
%         GRAPH - structure containing the edges of the graph;
%                 defined as global variable
% Outputs: Sx  - the time at which the network becomes operational
%          b - the critical number for configuration X;
%          perm     - the permutation induced by sorting X;
X;%X(30):0<X<1,>1.
global GRAPH
E=GRAPH.E;%18��*2��
n=max(E(:)); %number of nodes, n=14
A=zeros(n);  %incidence matrix,A=(14��*14��0)
[x_sorted,perm]=sort(X);% find permutation pi,x_sorted(30),perm(30)
b=0; % critical number 
%perm(:)'
for i=perm(:)'
    b=b+1;
    e=E(i,:); % which edge is up
    A(e,e)=1; % indicate that the nodes of 'e' are connected
    % find with which other nodes e(1) and e(2) are connected
    y=A(e(1),:) | A(e(2),:); 
    A(y,y)=1; % indicate the complete connectivity of the nodes
    struc_func=A(1,n); % if nodes 1 and n are connected, set H(X)=1
    % struc_func=all(A(1,:)); use this for all-terminal rlbty
    % if structure function is one, exit
     if struc_func, break,  end 
end
Sx=x_sorted(b);

function x=expt(u,a,b)
% generate from truncated exponential on [a,b]
% with coefficient 'u'
const=exp(-u*a)-exp(-u*b);
x=-log(exp(-u*a)-const*rand)/u;

function timestamp ( )
t = now;
c = datevec ( t );
s = datestr ( c, 0 );
fprintf ( 1, '%s\n', s );
return