#include "header.h"
#include "macro.h"

void sphere(unsigned long (*rng)(), char *rngname)
{
    const counter no_obs=20, no_pts=4000, edge=1000;
    const real ratio=edge/UNIMAX;
    const int minrns=240000;

    int fcmpr(const void *u1, const void *u2);

    register counter i, j, k;
    real d, dmin;
    real *x, *y, *z, *p, r3, pvalue;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |             THE 3DSPHERES TEST                              |\n");
        strcat(outstr, "        |Choose  4000 random points in a cube of edge 1000.  At each  |\n");
        strcat(outstr, "        |point, center a sphere large enough to reach the next closest|\n");
        strcat(outstr, "        |point. Then the volume of the smallest such sphere is (very  |\n");
        strcat(outstr, "        |close to) exponentially distributed with mean 120pi/3.  Thus |\n");
        strcat(outstr, "        |the radius cubed is exponential with mean 30. (The mean is   |\n");
        strcat(outstr, "        |obtained by extensive simulation).  The 3DSPHERES test gener-|\n");
        strcat(outstr, "        |ates 4000 such spheres 20 times.  Each min radius cubed leads|\n");
        strcat(outstr, "        |to a uniform variable by means of 1-exp(-r^3/30.), then a    |\n");
        strcat(outstr, "        | KSTEST is done on the 20 p-values.                          |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("\n                    The 3DSPHERES test");
    fprintf(outfile, "\n                    The 3DSPHERES test");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n\n                sample no       r^3             equiv. uni.\n");
    fprintf(outfile, "\n\n                sample no       r^3             equiv. uni.\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    x=(real*)malloc(no_pts*sizeof(real));
    y=(real*)malloc(no_pts*sizeof(real));
    z=(real*)malloc(no_pts*sizeof(real));
    p=(real*)malloc(no_obs*sizeof(real));

    for(i=1; i<=no_obs; ++i){
        dmin=10000000.;

        for(j=0; j<no_pts; ++j){
            x[j]=ratio*rng();
            y[j]=ratio*rng();
            z[j]=ratio*rng();
        }
        qsort(x, no_pts, sizeof(real), fcmpr);

        /* to compare with fortran counter part
            for(j=0; j<no_pts; ++j){
              y[j]=ratio*uni(filename);
              z[j]=ratio*uni(filename);
            }*/

        for(j=0; j<no_pts-1; ++j){
            for(k=j+1; k<no_pts; ++k){
                d=(x[k]-x[j])*(x[k]-x[j]);

                if(d>=dmin) break;
                d+=(y[k]-y[j])*(y[k]-y[j])+(z[k]-z[j])*(z[k]-z[j]);
                dmin=MIN(dmin, d);
            }
        }

        r3=dmin*sqrt(dmin);
        p[i-1]=1-exp(-MIN(r3/30., 20));
        printf("                   %-2lu           %-10.3f      %f\n", i, r3, p[i-1]);
        fprintf(outfile, "                   %-2lu           %-10.3f      %f\n", i, r3, p[i-1]);
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = p[i-1];
            overall.pknt++;
        }
    }
    //uni("close");

    free(x);
    free(y);
    free(z);

    printf("        --------------------------------------------------------------\n");
    fprintf(outfile, "        --------------------------------------------------------------\n");
    pvalue=KStest(p,no_obs);
    printf("                p-value for KS test on those %lu p-values: %f\n", no_obs, pvalue);
    fprintf(outfile, "                p-value for KS test on those %lu p-values: %f\n", no_obs, pvalue);

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    free(p);

    return;
}


/* SQUEEZE TEST:  How many iterations of k=k*uni()+1 are required
   to squeeze k down to 1, starting with k=2147483647=2^31-1?
   The exact distribution of the required j is used, with
   a chi-square test based on no_trials=100,000 tries.
   The mean of j is 23.064779, with variance 23.70971151.*/

#include "header.h"
#include "macro.h"

void squeez(unsigned long (*rng)(), char *rngname)
{
    const counter no_trials=100000;
    const real ratio=no_trials/1000000., std=sqrt(84);
    const int minrns=2306503;

    register counter i;
    register unsigned long k;
    register short j;

    counter f[43];
    real Ef[]={
        21.03,57.79,175.54,467.32,1107.83, 2367.84,
        4609.44,8241.16,13627.81,20968.49,30176.12,40801.97,52042.03,
        62838.28,72056.37,78694.51,82067.55,81919.35,78440.08,72194.12,
        63986.79,54709.31,45198.52,36136.61,28000.28,21055.67,15386.52,
        10940.20,7577.96,5119.56,3377.26,2177.87,1374.39,849.70,515.18,
        306.66, 179.39, 103.24, 58.51, 32.69, 18.03, 9.82, 11.21    };
    real tmp, chsq=0, pvalue;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |                 This is the SQUEEZE test                    |\n");
        strcat(outstr, "        | Random integers are floated to get uniforms on [0,1). Start-|\n");
        strcat(outstr, "        | ing with k=2^31=2147483647, the test finds j, the number of |\n");
        strcat(outstr, "        | iterations necessary to reduce k to 1, using the reduction  |\n");
        strcat(outstr, "        | k=ceiling(k*U), with U provided by floating integers from   |\n");
        strcat(outstr, "        | the file being tested.  Such j's are found 100,000 times,   |\n");
        strcat(outstr, "        | then counts for the number of times j was <=6,7,...,47,>=48 |\n");
        strcat(outstr, "        | are used to provide a chi-square test for cell frequencies. |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("\n                        RESULTS OF SQUEEZE TEST");
    fprintf(outfile, "\n                        RESULTS OF SQUEEZE TEST");
    if (strlen(rngname) > 0)
    {
        printf(" FOR %s", rngname);
        fprintf(outfile, " FOR %s", rngname);
    }
    printf("\n\n                    Table of standardized frequency counts\n");
    fprintf(outfile, "\n\n                    Table of standardized frequency counts\n");
    printf("                (obs-exp)^2/exp  for j=(1,..,6), 7,...,47,(48,...)\n             " );
    fprintf(outfile, "                (obs-exp)^2/exp  for j=(1,..,6), 7,...,47,(48,...)\n             " );

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    for(i=0; i<43; ++i){
        f[i]=0;
        Ef[i]*=ratio;
    }

    for(i=1; i<=no_trials; ++i){
        k=2147483647;
        j=0;

        /* squeeze k */
        while( (k!=1)&&(j<48) ){
            k=k*( rng()/UNIMAX )+1;
            ++j;
        }

        j=MAX(j-6,0);
        ++f[j];
    }
    //uni("close");

    /* compute chi-square */
    for(i=0; i<=42; ++i){
        tmp=(f[i]-Ef[i])/sqrt(Ef[i]);
        chsq+=tmp*tmp;
        //printf(" %6.1f ", tmp );
        printf(" %6.3f ", tmp*tmp );
        //fprintf(outfile, " %6.1f ", tmp );
        fprintf(outfile, " %6.3f ", tmp*tmp );
        if((i+1)%6==0)
        {
            printf("\n             ");
            fprintf(outfile, "\n             ");
        }
    }

    printf("\n                Chi-square with 42 degrees of freedom:%f\n", chsq);
    fprintf(outfile, "\n                Chi-square with 42 degrees of freedom:%f\n", chsq);
    //printf("                 z-score=%f, p-value=%8.6f\n",(chsq-42.)/std, 1-Chisq(42,chsq));
    //fprintf(outfile, "                 z-score=%f, p-value=%8.6f\n",(chsq-42.)/std, 1-Chisq(42,chsq));
//    pvalue = 1.0 - ginc(21.0, chsq/2.0);
    pvalue = ginc(21.0, chsq/2.0);
    printf("                z-score=%f, p-value=%8.6f\n",(chsq-42.)/std, pvalue);
    fprintf(outfile, "                z-score=%f, p-value=%8.6f\n",(chsq-42.)/std, pvalue);
    printf("        _____________________________________________________________\n\n");
    fprintf(outfile, "        _____________________________________________________________\n\n");

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    return;
}




#include "header.h"

static real chi_fit;
static int dgf;

int ucmpr(const void *u1, const void *u2);

/*compute the statistic of goodness of fit to a Poisson distribution*/
real P_fit(real lambda, counter *obs, int no_obs)
{
    counter *f, dim=no_obs/5;
    register int i=-1;
    register counter j, k=0;
    real rest=no_obs, *Ef;

    f=(counter*)calloc(dim, sizeof(counter));
    Ef=(real*)calloc(dim, sizeof(real));

    qsort(obs, no_obs, sizeof(counter), ucmpr);

    for(j=0; j<dim; ++j){
        while( Ef[j]<5 ){
            ++i;
            Ef[j]+=no_obs*Poisson(lambda, i);
        }

        while( obs[k]<=i ){
            ++f[j];
            ++k;
        }

        rest-=Ef[j];
        if( rest<5 ){
            Ef[j]+=rest;
            f[j]+=no_obs-k;
            break;
        }
    }

    chi_fit=0;
    for(i=0; i<=j; ++i){
        chi_fit+=(f[i]-Ef[i])*(f[i]-Ef[i])/Ef[i];
    }

    dgf=j;

    free(f);
    free(Ef);

//    return 1.0 - ginc(dgf/2.0,chi_fit/2.0);
    return ginc(dgf/2.0,chi_fit/2.0);
}

void bday(unsigned long (*rng)(), void (*restart_rng)(), char *rngname)
{
    const counter no_obs=500, no_bday=1024, no_bits=24;
    register const counter mask=pow(2,no_bits)-1;
    const real lambda=pow(no_bday,3)/(4*pow(2,no_bits));
    const int minrns=512000;

    register int rt;
    register int i, k, sum;
    uniform *bdspace;
    counter no_dup, *obs;
    real pvalue, *p;
    char outstr[2500]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |           This is the BIRTHDAY SPACINGS TEST                |\n");
        strcat(outstr, "        |Choose m birthdays in a \"year\" of n days.  List the spacings |\n");
        strcat(outstr, "        |between the birthdays.  Let j be the number of values that   |\n");
        strcat(outstr, "        |occur more than once in that list, then j is asymptotically  |\n");
        strcat(outstr, "        |Poisson distributed with mean m^3/(4n).  Experience shows n  |\n");
        strcat(outstr, "        |must be quite large, say n>=2^18, for comparing the results  |\n");
        strcat(outstr, "        |to the Poisson distribution with that mean.  This test uses  |\n");
        strcat(outstr, "        |n=2^24 and m=2^10, so that the underlying distribution for j |\n");
        strcat(outstr, "        |is taken to be Poisson with lambda=2^30/(2^26)=16. A sample  |\n");
        strcat(outstr, "        |of 200 j's is taken, and a chi-square goodness of fit test   |\n");
        strcat(outstr, "        |provides a p value.  The first test uses bits 1-24 (counting |\n");
        strcat(outstr, "        |from the left) from 32-bit integers in the specified file.   |\n");
        strcat(outstr, "        |The file is closed and reopened, then bits 2-25 of the same  |\n");
        strcat(outstr, "        |integers are used to provide birthdays, and so on to bits    |\n");
        strcat(outstr, "        |9-32. Each set of bits provides a p-value, and the nine  p-  |\n");
        strcat(outstr, "        |values provide a sample for a KSTEST.                        |\n");
        strcat(outstr, "        |------------------------------------------------------------ |\n\n");

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("                RESULTS OF BIRTHDAY SPACINGS");
    fprintf(outfile, "                RESULTS OF BIRTHDAY SPACINGS");
    if (strlen(rngname) > 0)
    {
        printf(" FOR %s", rngname);
        fprintf(outfile, " FOR %s", rngname);
    }
    printf("\n        (no_bdays=%lu, no_days/yr=2^%lu,",no_bday, no_bits);
    fprintf(outfile, "\n        (no_bdays=%lu, no_days/yr=2^%lu,",no_bday, no_bits);
    printf(" lambda=%.2f, sample size=%lu)\n\n", lambda, no_obs);
    fprintf(outfile, " lambda=%.2f, sample size=%lu)\n\n", lambda, no_obs);
    printf("        Bits used       mean            chisqr          p-value\n");
    fprintf(outfile, "        Bits used       mean            chisqr          p-value\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    obs=(counter*)malloc(no_obs*sizeof(counter));
    p=(real*)malloc((32-no_bits+1)*sizeof(real));
    bdspace=(uniform*)malloc(no_bday*sizeof(uniform));


#define GETDAY       ( (rng() >> rt) & mask )

    for(rt=32-no_bits; rt>=0; --rt){
        sum=0;

        for(k=0; k<no_obs; ++k){
            for(i=0; i<no_bday; ++i){
                bdspace[i]=GETDAY;
            }

            qsort(bdspace, no_bday, sizeof(uniform), ucmpr);

            for(i=no_bday-1; i>=1; --i){
                bdspace[i]-=bdspace[i-1];
            }
            qsort(bdspace, no_bday, sizeof(uniform), ucmpr);

            no_dup=0;
            for(i=1; i<no_bday; ++i){
                if(bdspace[i]!=bdspace[i-1]) continue;
                else ++no_dup;
            }
            sum+=no_dup;
            obs[k]=no_dup;
        }
        //uni("close");
	    restart_rng();

        p[rt]=P_fit(lambda, obs, no_obs);

        printf("         %lu to %d", 33-no_bits-rt,32-rt);
        fprintf(outfile, "         %lu to %d", 33-no_bits-rt,32-rt);
        printf("        %-5.2f           %-10.4f      %f\n", (real)sum/no_obs, chi_fit, p[rt]);
        fprintf(outfile, "        %-5.2f           %-10.4f      %f\n", (real)sum/no_obs, chi_fit, p[rt]);
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = p[rt];
            overall.pknt++;
        }

    }

    /*clean up*/
    free(bdspace);
    free(obs);

    pvalue=KStest(p,32-no_bits+1);

    printf("\n                 Chisquare degrees of freedom: %d\n", dgf);
    fprintf(outfile, "\n                 Chisquare degrees of freedom: %d\n", dgf);
    printf("        ---------------------------------------------------------------\n");
    fprintf(outfile, "        ---------------------------------------------------------------\n");
    printf("                p-value for KStest on those %lu p-values: %f\n\n",32-no_bits+1,pvalue);
    fprintf(outfile, "                p-value for KStest on those %lu p-values: %f\n\n",32-no_bits+1,pvalue);

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    free(p);

    return;
}



#include <stdio.h>
#include <math.h>
#include "header.h"


long kp(long []); //

void operm5(unsigned long (*rng)(), char *rngname)
{
    const int minrns=50000025;
    // Pointer to the binary file that stores a[] and b[]
    static FILE *infile;
    // An rray here has entries 1 more than that in Fortran as
    // the index starts from 0 in C,instead of 1 in Fortran.
    long u[1006];
    float t[121];
    double cq,a[1831],b[1831];
    //Auxiliary variables
        long i,j,jj,k,m,n;
    double v,pval;
    char outstr[2000]="";

    //Input a[],b[] from the binary file

    if((infile=fopen("cinv7.bin","rb"))==NULL )
    {
        printf("can't open the cinv7.bin file !!!\n");
        exit(1);
    }
    m=fread(&a[1],sizeof(double),1830,infile );
    m=fread(&b[1],sizeof(double),1830,infile );
    fclose(infile);

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |           THE OVERLAPPING 5-PERMUTATION TEST                |\n");
        strcat(outstr, "        |This is the OPERM5 test.  It looks at a sequence of ten mill-|\n");
        strcat(outstr, "        |ion 32-bit random integers.  Each set of five consecutive    |\n");
        strcat(outstr, "        |integers can be in one of 120 states, for the 5! possible or-|\n");
        strcat(outstr, "        |derings of five numbers.  Thus the 5th, 6th, 7th,...numbers  |\n");
        strcat(outstr, "        |each provide a state. As many thousands of state transitions |\n");
        strcat(outstr, "        |are observed,  cumulative counts are made of the number of   |\n");
        strcat(outstr, "        |occurences of each state.  Then the quadratic form in the    |\n");
        strcat(outstr, "        |weak inverse of the 120x120 covariance matrix yields a test  |\n");
        strcat(outstr, "        |that the 120 cellcounts came from the specified (asymptotic) |\n");
        strcat(outstr, "        |distribution with the specified means and 120x120 covariance.|\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }
    //Conduct the OPERM5 test
    printf("\n     The OPERM5 test for 10 million (overlapping) 5-tuples");
    fprintf(outfile, "\n     The OPERM5 test for 10 million (overlapping) 5-tuples");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf(",\n     p-values for 5 runs:");
    fprintf(outfile, ",\n     p-values for 5 runs:");

    if (maxrnavail < minrns)
    {
        printf("\nNot enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "\nNot enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    for (jj=1; jj<=5; ++jj)
    { //jjloop
        n=10000;
        for (i=1;i<=120;++i) //do 11
            {
            t[i]=(float) (-10000000./120.);
        }
        for (i=1001;i<= 1005;++i) //do 4
            {
            u[i]=rng();
        }
        for (i=1;i<=n;++i) //do 5
            {
            for (j=1;j<=5;++j) //do 6
                {
                u[j]=u[1000+j];
            }
            for (j=1;j<=1000;++j) //do 7
                {
                k=kp(&u[j])+1;
                t[k]=t[k]+1;
                u[j+5]=rng();
            }
        }
        cq=0.;
        k=0;
        for (i=1;i<=60;++i) //do 32
            {
            for (j=i;j<=60;++j) //do 32
                {
                k=k+1;
                if(i==j)
                {
                    cq=cq+a[k]*(t[i]*t[i]+t[i+60]*t[i+60])+2.*b[k]*t[i]*t[i+60];
                }
                else
                    {
                    cq+=2.*(a[k]*(t[i]*t[j]+t[i+60]*t[j+60])+b[k]*(t[i]*t[j+60]+t[i+60]*t[j]));
                }
            }
        }
        cq=cq /10000000.;
        v=23.141*exp(log(cq)/3. - 1.59304) - 23.09773;
        pval=.5+.5*sqrt(1. - exp(-.623*v*v) );
        if (v < 0.) pval=1. - pval;
        {
            if (jj < 5)
            {
                printf("%7.4f,",pval);
                fprintf(outfile, "%7.4f,",pval);
            }
            else
                {
                printf("%7.4f\n",pval);
                fprintf(outfile, "%7.4f\n",pval);
            }
        }
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = pval;
            overall.pknt++;
    }

    }//endjjloop
    printf("\n");
}//operm5()


long kp(long c[])
{
    long map[]=
        {
        39,38,37,36,41,40,54,55,56,57,58,59,49,48,52,53,50,51,42,43,
        44,45,46,47,33,32,31,30,35,34,12,13,14,15,16,17,29,28,24,25,
        27,26,21,20,19,18,23,22,2,3,5,4,1,0,10,11,9,8,6,7
    }; //60 elements
    long b[6];
    long i,j,L,s,t,k; //Auxiliary variables

    for (i=1;i<=5;++i)
        b[i]=c[i-1]; //do 7
        k=0;
    for (i=5;i>=2;--i) //do 2
        {
        t=b[1];
        L=1;
        for (j=2;j<=i;++j) //do 3
            {
            if (b[j] >= t)
            {
                t=b[j];
                L=j;
            }
        }
        k=i*k+L - 1;
        s=b[i];
        b[i]=b[L];
        b[L]=s;
    }
    if (k < 60)
        k=map[k];
    return k;
}//kp()
#include "header.h"

void osum(unsigned long (*rng)(), char *rngname)
{
    const int minrns=199000;
    const counter no_obs=10, no_sum=100, no_num=100;
    const real mean=.5*no_num, rstd=sqrt(12);

    counter i, j, k;
    real *x, *y, *p, *pv, tmp, sum, a, b;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |            The  OVERLAPPING SUMS test                       |\n");
        strcat(outstr, "        |Integers are floated to get a sequence U(1),U(2),... of uni- |\n");
        strcat(outstr, "        |form [0,1) variables.  Then overlapping sums,                |\n");
        strcat(outstr, "        |  S(1)=U(1)+...+U(100), S2=U(2)+...+U(101),... are formed.   |\n");
        strcat(outstr, "        |The S's are virtually normal with a certain covariance mat-  |\n");
        strcat(outstr, "        |rix.  A linear transformation of the S's converts them to a  |\n");
        strcat(outstr, "        |sequence of independent standard normals, which are converted|\n");
        strcat(outstr, "        |to uniform variables for a KSTEST.                           |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }

    printf("                        Results of the OSUM test");
    fprintf(outfile, "                        Results of the OSUM test");
    if (strlen(rngname) >0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n\n                        Test no                 p-value\n");
    fprintf(outfile, "\n\n                        Test no                 p-value\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    x=(real*)malloc(no_num*sizeof(real));
    y=(real*)malloc(no_num*sizeof(real));
    p=(real*)malloc(no_sum*sizeof(real));
    pv=(real*)malloc(no_obs*sizeof(real));

    for(i=1; i<=no_obs; ++i){
        for(j=0; j<no_sum; ++j){

            /* get a sequence of numbers and add them up */
            sum=0;
            for(k=0; k<no_num; ++k){
                y[k]=rng()/UNIMAX;
                sum+=y[k];
            }

            /* discard the first number in the sequence and get another number
                  add up the new sequence of numbers */

            for(k=1; k<no_num; ++k){
                tmp=y[k-1];
                y[k-1]=(sum-mean)*rstd;
                sum-=(tmp-rng()/UNIMAX);
            }
            y[no_num-1]=(sum-mean)*rstd;

            x[0]=y[0]/sqrt(no_num);

            x[1]= -x[0]*(no_num-1)/sqrt(2*no_num-1.)+y[1]*sqrt(no_num/(2*no_num-1.));
            x[0]=1.0-cPhi(x[0]);
            x[1]=1.0-cPhi(x[1]);

            for(k=2; k<no_num; ++k){
                a=2*no_num+1-k;
                b=2*a-2;
                x[k]=y[0]/sqrt(a*b)-sqrt((a-1)/(b+2))*y[k-1]+y[k]*sqrt(a/b);
                x[k]=1.0-cPhi(x[k]);
            }

            p[j]=KStest(x, no_num);
        }

        pv[i-1]=KStest(p, no_num);
        printf("                          %-2lu                    %f\n", i, pv[i-1]);
        fprintf(outfile, "                          %-2lu                    %f\n", i, pv[i-1]);
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = pv[i-1];
            overall.pknt++;
        }
    }
    //uni("close");

    printf("        _____________________________________________________________\n\n");
    fprintf(outfile, "        _____________________________________________________________\n\n");

    free(x);
    free(y);
    free(p);

    tmp=KStest(pv, no_obs);
    free(pv);

    printf("                p-value for %lu kstests on %lu sums: %f\n", no_obs, no_sum, tmp);
    fprintf(outfile, "                p-value for %lu kstests on %lu sums: %f\n", no_obs, no_sum, tmp);

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = tmp;
        overall.pknt++;
    }

    return;
}



/*******Test ranks of 100,000 6x8 binary matrices**************
 *******Each row a byte from a RNG, overlapping rows*************/

#include "header.h"
#include "macro.h"

/* define a binary matrix */
typedef struct binmatrix
{

    uniform *row;
    int no_row, no_col;
    unsigned long mask;

}
binmatrix;

/*print the title*/
void rnk_ttl(char *test, char *rngname)
{
    char outstr[2000]="";

    if (terse == 0)
    {
        if( test[0]=='6' )
        {
            strcat(outstr, "\n        |-------------------------------------------------------------|\n");
            strcat(outstr, "        |This is the BINARY RANK TEST for 6x8 matrices.  From each of |\n");
            strcat(outstr, "        |six random 32-bit integers from the generator under test, a  |\n");
            strcat(outstr, "        |specified byte is chosen, and the resulting six bytes form a |\n");
            strcat(outstr, "        |6x8 binary matrix whose rank is determined.  That rank can be|\n");
            strcat(outstr, "        |from 0 to 6, but ranks 0,1,2,3 are rare; their counts are    |\n");
            strcat(outstr, "        |pooled with those for rank 4. Ranks are found for 100,000    |\n");
            strcat(outstr, "        |random matrices, and a chi-square test is performed on       |\n");
            strcat(outstr, "        |counts for ranks <=4, 5 and 6.                               |\n");
            strcat(outstr, "        |-------------------------------------------------------------|\n");
        }

        if( test[1]=='1' )
        {
            strcat(outstr, "\n        |-------------------------------------------------------------|\n");
            strcat(outstr, "        |This is the BINARY RANK TEST for 31x31 matrices. The leftmost|\n");
            strcat(outstr, "        |31 bits of 31 random integers from the test sequence are used|\n");
            strcat(outstr, "        |to form a 31x31 binary matrix over the field {0,1}. The rank |\n");
            strcat(outstr, "        |is determined. That rank can be from 0 to 31, but ranks< 28  |\n");
            strcat(outstr, "        |are rare, and their counts are pooled with those for rank 28.|\n");
            strcat(outstr, "        |Ranks are found for 40,000 such random matrices and a chisqu-|\n");
            strcat(outstr, "        |are test is performed on counts for ranks 31,30,28 and <=28. |\n");
            strcat(outstr, "        | (The 31x31 choice is based on the unjustified popularity of |\n");
            strcat(outstr, "        |  the proposed \"industry standard\" generator                 |\n");
            strcat(outstr, "        |  x(n) = 16807*x(n-1) mod 2^31-1, not a very good one.)      |\n");
            strcat(outstr, "        |-------------------------------------------------------------|\n");
        }

        if( test[1]=='2' )
        {
            strcat(outstr, "\n        |-------------------------------------------------------------|\n");
            strcat(outstr, "        |This is the BINARY RANK TEST for 32x32 matrices. A random 32x|\n");
            strcat(outstr, "        |32 binary matrix is formed, each row a 32-bit random integer.|\n");
            strcat(outstr, "        |The rank is determined. That rank can be from 0 to 32. Ranks |\n");
            strcat(outstr, "        |less than 29 are rare, and their counts are pooled with those|\n");
            strcat(outstr, "        |for rank 29.  Ranks are found for 40,000 such random matrices|\n");
            strcat(outstr, "        |and a chisquare test is performed on counts for ranks  32,31,|\n");
            strcat(outstr, "        |30 and <=29.                                                 |\n");
            strcat(outstr, "        |-------------------------------------------------------------|\n");
        }

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("\n                Rank test for binary matrices (%s)", test);
    fprintf(outfile, "\n                Rank test for binary matrices (%s)", test);
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n");
    fprintf(outfile, "\n");
    return;
}

/*compute the rank of a binary matrix*/
int rkbm(binmatrix bm)
{
    register int i, j, k, rt=0;
    int rank=0;
    uniform tmp;

    for(k=0; k<bm.no_row; ++k){
        i=k;

        while( ( (bm.row[i]>>rt)&1 ) == 0 ){
            ++i;

            if( i<bm.no_row ){
                continue;
            }
            else {
                ++rt;
                if( rt<bm.no_col ){
                    i=k;
                    continue;
                }
            }

            return rank;
        }

        ++rank;
        if( i!=k ){
            tmp=bm.row[i];
            bm.row[i]=bm.row[k];
            bm.row[k]=tmp;
        }

        for(j=i+1; j<bm.no_row; ++j){
            if( ( (bm.row[j] >> rt) & 1 ) == 0 ) continue;
            else bm.row[j] ^= bm.row[k];
        }

        ++rt;
    }

    return rank;
}

int first;
/* perform the test and calculate test-stat */
real rnk_stat(unsigned long (*rng)(), void (*restart_rng)(), counter no_mtr, char *test, int rt)
{
    real p6[]={
        .009443, 0.217439, 0.773118    };
    real p30[]={
        .0052854502, .1283502644, .5775761902, .2887880952    };

    binmatrix bm;
    register counter i, j;
    register int cls, llim;
    char cat[2][4]={
        {
            "r<="        }
        , {
            "r="        }
    };
    counter *f;

    short df=3;
    real pvalue, *p;
    real Ef, chsq=0, tmp;
    char outstr[2000]="";

    switch(test[1]){
    case '1':
        bm.no_row=bm.no_col=31;
        bm.mask=pow(2,31)-1;
        llim=28;
        p=p30;
        break;
    case '2':
        bm.no_row=bm.no_col=32;
        bm.mask=pow(2,32)-1;
        llim=29;
        p=p30;
        break;
    default:
        {
            df=2;
            bm.no_row=6;
            bm.no_col=8;
            bm.mask=pow(2,8)-1;
            llim=4;
            p=p6;
	    if (first == 0)
	    {
		strcat(outstr, "        (Bits of a 32-bit integer are numbered left to right, 1,2,...,32)\n");
		strcat(outstr, "        Rank of a 6x8 binary matrix, rows eight bits from the RNG\n");
		printf(outstr);
		fprintf(outfile, outstr);
                printf("        Typical output looks like this for bits %d to %d:\n", 25-rt, 32-rt);
                fprintf(outfile, "        Typical output looks like this for bits %d to %d:\n", 25-rt, 32-rt);
	    }
            break;
        }
    }


    bm.row=(uniform*)malloc(bm.no_row*sizeof(uniform));

    f=(counter*)calloc( (df+1), sizeof(counter));

    if (test[1] == '1' || test[2] == '2' || first == 0)
    {
        printf("\n        RANK    OBSERVED        EXPECTED        (O-E)^2/E       SUM\n\n");
        fprintf(outfile, "\n        RANK    OBSERVED        EXPECTED        (O-E)^2/E       SUM\n\n");
    }

    for( i=1; i<=no_mtr; ++i ){

        /* get the rows of a matrix */
        for(j=0; j<bm.no_row; ++j){
            switch(test[1]){
            case '1':
                bm.row[j]=( rng()>>1 );
                break;
            case '2':
                bm.row[j]=rng();
                break;
            default:
                bm.row[j]=( rng()>>rt );
                break;
            }
            bm.row[j] &= bm.mask;
        }

        cls=rkbm(bm);
        cls=MAX(llim,cls)-llim;
        ++f[cls];
    }

    /* compute chi-square */
    for(i=0; i<=df; ++i){
        Ef=no_mtr* ( *(p+i) );
        tmp=(f[i]-Ef)*(f[i]-Ef)/Ef;
        chsq+=tmp;
	if (test[1] == '1' || test[2] == '2' || first == 0)
	{
        printf("        %-3s%2lu   %-12lu    %-12.1f", cat[MIN(1,i)], i+llim, f[i], Ef);
        fprintf(outfile, "        %-3s%2lu   %-12lu    %-12.1f", cat[MIN(1,i)], i+llim, f[i], Ef);
        printf("    %-12.3f    %-12.3f\n", tmp, chsq);
        fprintf(outfile, "    %-12.3f    %-12.3f\n", tmp, chsq);
	}
    }
    //uni("close");
    restart_rng();

    /*  cfree(f, (df+1), sizeof(counter));*/
    free(bm.row);

    //pvalue=1-Chisq( df, chsq );
//    pvalue=1.0-ginc( df/2.0, chsq/2.0 );
    pvalue=ginc( df/2.0, chsq/2.0 );
    if (test[1] == '1' || test[1] == '2')
    {
    printf("\n                chi-square = %.3f with df = %d;", chsq, df);
    fprintf(outfile, "\n                chi-square = %.3f with df = %d;", chsq, df);
    printf("  p-value = %.3f\n", pvalue);
    fprintf(outfile, "  p-value = %.3f\n", pvalue);

    printf("        --------------------------------------------------------------\n");
    fprintf(outfile, "        --------------------------------------------------------------\n");
    }
    else
    {
	if (first == 0)
	{
            printf("            p = 1-exp(-SUM/2) = %.5f\n", pvalue);
            fprintf(outfile, "            p = 1-exp(-SUM/2) = %.5f\n", pvalue);
            printf("        but such output is surprised to save space.\n");
            fprintf(outfile, "        but such output is surprised to save space.\n");
            printf("                The 25 p values:\n");
            fprintf(outfile, "                The 25 p values:\n");
	}
        printf("        b-rank test for bits %2d to %2d, p=%.5f\n", 25-rt, 32-rt, pvalue);
        fprintf(outfile, "        b-rank test for bits %2d to %2d, p=%.5f\n", 25-rt, 32-rt, pvalue);
    }
    first++;

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    return pvalue;
}

/* type "6x8", "31x31" or "32x32" (including the quotation mark) to call
   each test.*/
void binrnk(unsigned long (*rng)(), void (*restart_rng)(), char *test, char *rngname)
{
    int minrns=600000;
    counter no_matrices=100000;
    short rt=24, not6x8=strncmp(test, "6 x 8", 1);
    real *p, pvalue;

    if( not6x8 ){
        rt=0;
        no_matrices=40000;
		first = 0;
        if (strncmp(test, "31x31", 2)==0)
           minrns = 1240000;
        else
           minrns = 1280000;
    }

    rnk_ttl(test, rngname);

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    p=(real*)malloc( (rt+1)*sizeof(real) );

    do{
        p[rt]=rnk_stat(rng, restart_rng, no_matrices, test, rt);
        --rt;
    }
    while(rt>=0);

    if( not6x8 ) return;

    printf("\n        TEST SUMMARY, 25 tests, each on 100,000 random 6x8 matrices\n");
    fprintf(outfile, "\n        TEST SUMMARY, 25 tests, each on 100,000 random 6x8 matrices\n");
    printf("        The above should be 25 uniform [0,1] random variables:\n");
    fprintf(outfile, "        The above should be 25 uniform [0,1] random variables:\n");
/*
    for(rt=24; rt>=0; --rt){
        if( (rt+1)%5==0 )
        {
            printf("\n");
            fprintf(outfile, "\n");
        }
        printf("        %-12.6f", p[rt]);
        fprintf(outfile, "       %-12.6f", p[rt]);
    }
*/
    pvalue = KStest(p, 25);
    printf("        The KS test for those 25 supposed UNI's yields p = %f\n", pvalue);
    fprintf(outfile, "        The KS test for those 25 supposed UNI's yields p = %f\n", pvalue);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    free(p);

    return;
}




#include <stdio.h>
#include <math.h>
#include "header.h"


#define dx(r,s) ((x[r]-x[s])*(x[r]-x[s]))
#define dy(r,s) ((y[r]-y[s])*(y[r]-y[s]))
#define min(a,b) ( a<b ? a : b)
void mindist(unsigned long (*rng)(), char *rngname)
{
    const int minrns=160000;
    unsigned long i,j,k,k1,n=8000;
    float m,x[8000],y[8000];
    real pval[100], pvalue;
    int pcnt = 0;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |              THE MINIMUM DISTANCE TEST                      |\n");
        strcat(outstr, "        |It does this ten times:  choose n=8000 random points in a    |\n");
        strcat(outstr, "        |square of side 10000.  Find d, the minimum distance between  |\n");
        strcat(outstr, "        |the (n^2-n)/2 pairs of points.  If the points are truly inde-|\n");
        strcat(outstr, "        |pendent uniform, then d^2, the square of the minimum distance|\n");
        strcat(outstr, "        |should be (very close to) exponentially distributed with mean|\n");
        strcat(outstr, "        |.995 .  Thus 1-exp(-d^2/.995) should provide a p-value and  a|\n");
        strcat(outstr, "        |KSTEST on the resulting 10 values serves as a test of uni-   |\n");
        strcat(outstr, "        |formity for those samples of 8000 random points in a square. |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("                Results for the MINIMUM DISTANCE test");
    fprintf(outfile, "                Results for the MINIMUM DISTANCE test");
    //scanf("%d",&iuni);
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n\n");
    fprintf(outfile, "\n\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    for (k1=0; k1<1; k1++)
    {
        for (k=1; k<11; k++)
        {
            m=100000.;
            for(i=0; i<n; i++)
            { //iloop
                //iuni=69069*iuni+12345;
                x[i]=rng()*2.3283064e-6;
                //iuni=69069*iuni+12345;
                y[i]=rng()*2.3283064e-6;
            }//endiloop

            for (i=0; i<n-1; i++)
            {
                for(j=i+1; j<n; j++)
                    m=min(m,dx(i,j)+dy(i,j));
            }
            /*  faster mindist? No---slower
               for(i=0;i<n;i++)        {
                   for(j=1;j<n-i;j++){
                       if(x[j]>x[j+1])
             {t=x[j+1];x[j+1]=x[j];x[j]=t;t=y[j+1];y[j+1]=y[j];y[j]=t;}
                                     }  }
            */
            pval[pcnt] = 1.0 - exp(-m/.995);
            printf("%6.4f,", pval[pcnt]);
            fprintf(outfile, "%6.4f,", pval[pcnt]);
            if (overall.pknt < overall.max) {
               overall.pval[overall.pknt] = pval[pcnt];
               overall.pknt++;
            }
	    pcnt++;
        }
        printf("\n");
        fprintf(outfile, "\n");
    }
    //uni("close");
    pvalue = KStest(pval, 10);
    printf(" The KS test for those 10 p-values: %f\n", pvalue);
    fprintf(outfile, " The KS test for those 10 p-values: %f\n", pvalue);
    if (overall.pknt < overall.max) {
       overall.pval[overall.pknt] = pvalue;
       overall.pknt++;
            }
}
#include "header.h"
#include "macro.h"

void park(unsigned long(*rng)(), char *rngname)
{
    const int minrns=240020;
    const counter no_obs=10, side=100;
    const counter no_trials=12000;
    const real ratio=side/UNIMAX, mu=3523, sigma=21.9;

    register counter no_succ, j, k;
    real xtmp, ytmp;
    real *x, *y, mean, var, z, *p, pvalue;
    counter sum=0, ss=0, i;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |              THIS IS A PARKING LOT TEST                     |\n");
        strcat(outstr, "        |In a square of side 100, randomly \"park\" a car---a circle of |\n");
        strcat(outstr, "        |radius 1.   Then try to park a 2nd, a 3rd, and so on, each   |\n");
        strcat(outstr, "        |time parking \"by ear\".  That is, if an attempt to park a car |\n");
        strcat(outstr, "        |causes a crash with one already parked, try again at a new   |\n");
        strcat(outstr, "        |random location. (To avoid path problems, consider parking   |\n");
        strcat(outstr, "        |helicopters rather than cars.)   Each attempt leads to either|\n");
        strcat(outstr, "        |a crash or a success, the latter followed by an increment to |\n");
        strcat(outstr, "        |the list of cars already parked. If we plot n: the number of |\n");
        strcat(outstr, "        |attempts, versus k: the number successfully parked, we get a |\n");
        strcat(outstr, "        |curve that should be similar to those provided by a perfect  |\n");
        strcat(outstr, "        |random number generator.  Theory for the behavior of such a  |\n");
        strcat(outstr, "        |random curve seems beyond reach, and as graphics displays are|\n");
        strcat(outstr, "        |not available for this battery of tests, a simple characteriz|\n");
        strcat(outstr, "        |ation of the random experiment is used: k, the number of cars|\n");
        strcat(outstr, "        |successfully parked after n=12,000 attempts. Simulation shows|\n");
        strcat(outstr, "        |that k should average 3523 with sigma 21.9 and be approximate|\n");
        strcat(outstr, "        |to normally distributed.  Thus (k-3523)/21.9 should serve as |\n");
        strcat(outstr, "        |a standard normal variable, which, converted to a p  uniform |\n");
        strcat(outstr, "        |in [0,1), provides input to a KSTEST based on a sample of 10.|\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("\n                CDPARK");
    fprintf(outfile, "\n                CDPARK");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf(": result of %lu tests\n", no_obs);
    fprintf(outfile, ": result of %lu tests\n", no_obs);
    printf("          (Of %lu tries, the average no. of successes", no_trials);
    fprintf(outfile, "          (Of %lu tries, the average no. of successes", no_trials);
    printf(" should be \n           %.1f with sigma=%.1f)\n\n", mu, sigma);
    fprintf(outfile, " should be \n           %.1f with sigma=%.1f)\n\n", mu, sigma);
    printf("           No. succeses         z-score         p-value\n");
    fprintf(outfile, "           No. succeses         z-score         p-value\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    p=(real*)malloc(no_obs*sizeof(real));
    x=(real*)malloc(no_trials*sizeof(real));
    y=(real*)malloc(no_trials*sizeof(real));

#define PARK  { xtmp=ratio*rng(); ytmp=ratio*rng();}
#define CRASH   (ABS(x[k]-xtmp)<=1 && ABS(y[k]-ytmp)<=1)

    for(i=1; i<=no_obs; ++i){
        PARK /* the first parking */
        x[0]=xtmp;
        y[0]=ytmp;
        no_succ=1;

        for(j=0; j<no_trials; ++j){
            PARK /* succesive parking */
            for(k=0; ; ){
                if( CRASH ){
                    break;
                }

                ++k;
                if(k<no_succ){
                    continue;
                }

                x[no_succ]=xtmp;
                y[no_succ]=ytmp;
                ++no_succ;
                break;
            }
        }

        sum+=no_succ;
        ss+=no_succ*no_succ;

        z=(no_succ-mu)/sigma;
        p[i-1]=1.0-cPhi(z);

        printf("                %-6lu   %14.4f         %f\n", no_succ, z, p[i-1]);
        fprintf(outfile, "                %-6lu   %14.4f         %f\n", no_succ, z, p[i-1]);
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = p[i-1];
            overall.pknt++;
        }
    }

    //uni("close");

    mean=(real)sum/no_obs;
    var=(real)ss/no_obs-mean*mean;

    printf("          Square side=%lu, avg. no. parked=%.2f", side, mean);
    fprintf(outfile, "          Square side=%lu, avg. no. parked=%.2f", side, mean);
    printf(" sample std.=%.2f\n", sqrt(var));
    fprintf(outfile, " sample std.=%.2f\n", sqrt(var));

    pvalue=KStest(p, no_obs);
    printf("             p-value of the KSTEST for those %lu", no_obs);
    fprintf(outfile, "             p-value of the KSTEST for those %lu", no_obs);
    printf(" p-values: %f\n\n", pvalue);
    fprintf(outfile, " p-values: %f\n\n", pvalue);

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    free(p);
    free(x);
    free(y);

    return;
}



/*THE OVERLAPPING 20-tuples TEST BITSTREAM, 20 BITS PER WORD, N words
 If n=2^22, should be 19205.3 missing 20-letter words, sigma 167.
 If n=2^21, should be 141909 missing 20-letter words, sigma   428.
 If n=2^20, should be 385750 missing 20-letter words, sigma   512 */

#include "header.h"

void bitst(unsigned long(*rng)(), char *rngname)
{
    const int minrns=1310721;
    const counter nb_pw=20, power=21, no_obs=20;
    const counter no_bits=pow(2,power-5), no_wds=pow(2,power);
    const counter dim=pow(2,nb_pw-5);
    register counter mask=pow(2,nb_pw)-1;
    const real mean=pow(2,nb_pw)*exp(-pow(2,(power-nb_pw))), std=428;

    register uniform w20, w32;
    register counter i, j, k, l, u, no_mswds=0;
    counter bitmask[32], *wds;
    real z, pvalue;
    char outstr[2000]="";

    for(i=0; i<32; ++i){
        bitmask[i]=pow(2,i);
    }

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |                  THE BITSTREAM TEST                         |\n");
        strcat(outstr, "        |The file under test is viewed as a stream of bits. Call them |\n");
        strcat(outstr, "        |b1,b2,... .  Consider an alphabet with two \"letters\", 0 and 1|\n");
        strcat(outstr, "        |and think of the stream of bits as a succession of 20-letter |\n");
        strcat(outstr, "        |\"words\", overlapping.  Thus the first word is b1b2...b20, the|\n");
        strcat(outstr, "        |second is b2b3...b21, and so on.  The bitstream test counts  |\n");
        strcat(outstr, "        |the number of missing 20-letter (20-bit) words in a string of|\n");
        strcat(outstr, "        |2^21 overlapping 20-letter words.  There are 2^20 possible 20|\n");
        strcat(outstr, "        |letter words.  For a truly random string of 2^21+19 bits, the|\n");
        strcat(outstr, "        |number of missing words j should be (very close to) normally |\n");
        strcat(outstr, "        |distributed with mean 141,909 and sigma 428.  Thus           |\n");
        strcat(outstr, "        | (j-141909)/428 should be a standard normal variate (z score)|\n");
        strcat(outstr, "        |that leads to a uniform [0,1) p value.  The test is repeated |\n");
        strcat(outstr, "        |twenty times.                                                |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n");

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("\n                THE OVERLAPPING 20-TUPLES BITSTREAM TEST");
    fprintf(outfile, "\n                THE OVERLAPPING 20-TUPLES BITSTREAM TEST");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n         (%lu bits/word, %lu words", nb_pw, no_wds);
    fprintf(outfile, "\n         (%lu bits/word, %lu words", nb_pw, no_wds);
    printf(" %lu bitstreams.", no_obs );
    fprintf(outfile, " %lu bitstreams.", no_obs );
    printf(" No. missing words \n          should average %.2f", mean);
    fprintf(outfile, " No. missing words \n          should average %.2f", mean);
    printf(" with sigma=%.2f.)\n", std);
    fprintf(outfile, " with sigma=%.2f.)\n", std);
    printf("        ----------------------------------------------------------------\n");
    fprintf(outfile, "        ----------------------------------------------------------------\n");
    printf("                   BITSTREAM test results.\n\n");
    fprintf(outfile, "                   BITSTREAM test results.\n\n");
    printf("        Bitstream       No. missing words       z-score         p-value\n");
    fprintf(outfile, "        Bitstream       No. missing words       z-score         p-value\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    wds=(counter*)malloc(dim*sizeof(counter));

    w20 = rng();

    
    for(i=1; i<=no_obs; ++i){
        for(j=0; j<dim; ++j) wds[j]=0;

        for(j=0; j<no_bits; ++j){
            w32=rng();

            for(k=1; k<=32; ++k){
                w20 <<=1;
                w20 += (w32 & 1);
                w20 &= mask;
                l = w20 & 31;
                u = w20 >> 5;
                wds[u] |= bitmask[l];
                w32 >>=1;
            }
        }

        /*count no. of empty cells (=no. missing words)*/
        no_mswds=0;
        for(j=0; j<dim; ++j){
            for(k=0; k<32; ++k){
                if( (wds[j] & bitmask[k]) == 0 ) ++no_mswds;
            }
        }

        z=(no_mswds-mean)/std;
	    pvalue = 1.0-cPhi(z);
        printf("           %-2lu           %-12lu            % .2f           %f\n", i, no_mswds, z, pvalue);
        fprintf(outfile, "           %-2lu           %-12lu            % .2f           %f\n", i, no_mswds, z, pvalue);
        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = pvalue;
            overall.pknt++;
        }

    }

    //uni("close");
    free(wds);
    printf("        ----------------------------------------------------------------\n");
    fprintf(outfile, "        ----------------------------------------------------------------\n");

    return;
}


#include "header.h"

typedef enum {
    A,B,C,D,E}
letters;

/*convert a byte to a letter*/
letters b2l(int byte)
{
    register int cnt1s=0, tmp, j;

    for(j=0; j<8; ++j){
        tmp=(byte>>j) & 1;
        if( tmp==1 ) ++cnt1s;
    }

    if(cnt1s<3) return A;

    switch( cnt1s ){
    case 3:
        return B;
    case 4:
        return C;
    case 5:
        return D;
    default:
        break;
    }

    return E;
}

/* get a byte from a stream of bytes */
int getb(unsigned long (*rng)(), int rt)
{
    static short rest=0;
    static uniform wd;

    if(rest==0){
        wd=rng();
        rest=4;
    }

    --rest;

    return ( (wd >> rest*8) & 255 ); /*255=pow(2,8)-1*/
}

/* get a specific byte of a random integer */
int getsb(unsigned long (*rng)(), int rt)
{
    return ( (rng() >> rt) & 255 );
}

/* count the 1's in the sequence of bytes */
real cnt_stat(unsigned long (*rng)(), void (*restart_rng)(), counter no_wds, char *test, int rshft)
{
    const real mean=2500, std=sqrt(5000);
    const real prob[]={
        37/256.,56/256.,70/256.,56/256.,37/256.    };

    int (*byte)(unsigned long(*rng)(), int);

    register int wd;
    register counter i;

    short j, s;
    counter *f=NULL, f4[625], f5[3125];
    real Ef, chsq=0, z, pvalue;

    if( test[1]=='p' ){
        byte=getsb;
        printf("        %-2d to %-2d  ", 25-rshft,32-rshft);
        fprintf(outfile, "        %-2d to %-2d  ", 25-rshft,32-rshft);
    }
    else{
        byte=getb;
        printf("                  ");
        fprintf(outfile, "                  ");
    }

    for(i=0; i<625; ++i){
        f4[i]=0;
        f5[i]=0;
    }

    for(i=625; i<3125; ++i){
        f5[i]=0;
    }

#define BYTE  ( byte(rng, rshft) )
    wd=(625*b2l(BYTE)+125*b2l(BYTE)+25*b2l(BYTE)+5*b2l(BYTE)+b2l(BYTE));

    for(i=1; i<no_wds; ++i){
        wd %= 625; /*Erase leftmost letter of w*/
        ++f4[wd];

        wd=5*wd+b2l(BYTE); /*Shift wd left, add new letter*/
        ++f5[wd];
    }

    /* compute Q5-Q4, where Q4,Q5=sum(obs-exp)**2/exp */
    for(s=4; s<=5; ++s){
        int ltrspwd=0, wdspos=0;
        letters ltr;

        switch(s){
        case 4:
            wdspos=625;
            f=f4;
            ltrspwd=4;
            break;
        case 5:
            wdspos=3125;
            f=f5;
            chsq=-chsq;
            ltrspwd=5;
            break;
        }

        for(i=0; i<wdspos; ++i){
            Ef=no_wds;
            wd=i;

            for(j=0; j<ltrspwd; ++j){
                ltr=wd%5;
                Ef*=prob[ltr];
                wd/=5;
            }

            chsq+=( *(f+i)-Ef )*( *(f+i)-Ef )/Ef;
        }
    }
    //uni("close");
    restart_rng();

    z=(chsq-mean)/std;
    pvalue = 1.0-cPhi(z);
    printf(" %12.2f     %10.3f          %f\n", chsq, z, pvalue);
    fprintf(outfile, " %12.2f     %10.3f          %f\n", chsq, z, pvalue);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

    return chsq;
}

/*print the title*/
void cnt_ttl(char *test, char *rngname)
{
    char outstr[2000]="";

    if( strncmp(test, "specific", 2 )==0){
        if (terse == 0)
        {
            strcat(outstr, "\n        |-------------------------------------------------------------|\n");
            strcat(outstr, "        |    This is the COUNT-THE-1's TEST for specific bytes.       |\n");
            strcat(outstr, "        |Consider the file under test as a stream of 32-bit integers. |\n");
            strcat(outstr, "        |From each integer, a specific byte is chosen , say the left- |\n");
            strcat(outstr, "        |most: bits 1 to 8. Each byte can contain from 0 to 8 1's,    |\n");
            strcat(outstr, "        |with probabilitie 1,8,28,56,70,56,28,8,1 over 256.  Now let  |\n");
            strcat(outstr, "        |the specified bytes from successive integers provide a string|\n");
            strcat(outstr, "        |of (overlapping) 5-letter words, each \"letter\"  taking values|\n");
            strcat(outstr, "        |A,B,C,D,E. The letters are determined  by the number of 1's, |\n");
            strcat(outstr, "        |in that byte: 0,1,or 2 ---> A, 3 ---> B, 4 ---> C, 5 ---> D, |\n");
            strcat(outstr, "        |and  6,7 or 8 ---> E.  Thus we have a monkey at a typewriter |\n");
            strcat(outstr, "        |hitting five keys with with various probabilities: 37,56,70, |\n");
            strcat(outstr, "        |56,37 over 256. There are 5^5 possible 5-letter words, and   |\n");
            strcat(outstr, "        |from a string of 256,000 (overlapping) 5-letter words, counts|\n");
            strcat(outstr, "        |are made on the frequencies for each word. The quadratic form|\n");
            strcat(outstr, "        |in the weak inverse of the covariance matrix of the cell     |\n");
            strcat(outstr, "        |counts provides a chisquare test: Q5-Q4, the difference of   |\n");
            strcat(outstr, "        |the naive Pearson  sums of (OBS-EXP)^2/EXP on counts for 5-  |\n");
            strcat(outstr, "        |and 4-letter cell  counts.                                   |\n");
            strcat(outstr, "        |-------------------------------------------------------------|\n");
            printf(outstr);
            fprintf(outfile, outstr);
        }
        printf("\n                Test results for specific bytes");
        fprintf(outfile, "\n                Test results for specific bytes");
        if (strlen(rngname) > 0)
        {
            printf(" for %s", rngname);
            fprintf(outfile, " for %s", rngname);
        }
        printf("\n");
        fprintf(outfile, "\n");
    }

    else{
        if (terse == 0)
        {
            strcat(outstr, "\n        |-------------------------------------------------------------|\n");
            strcat(outstr, "        |    This is the COUNT-THE-1's TEST on a stream of bytes.     |\n");
            strcat(outstr, "        |Consider the file under test as a stream of bytes (four per  |\n");
            strcat(outstr, "        |32 bit integer).  Each byte can contain from 0 to 8 1's      |\n");
            strcat(outstr, "        |with probabilities 1,8,28,56,70,56,28,8,1 over 256.  Now let |\n");
            strcat(outstr, "        |the stream of bytes provide a string of overlapping  5-letter|\n");
            strcat(outstr, "        |words, each \"letter\" taking values A,B,C,D,E. The letters are|\n");
            strcat(outstr, "        |determined by the number of 1's in a byte: 0,1,or 2 yield A  |\n");
            strcat(outstr, "        |3 yields B, 4 yields C, 5 yields D and 6,7 or 8 yield E. Thus|\n");
            strcat(outstr, "        |we have a monkey at a typewriter hitting five keys with vari-|\n");
            strcat(outstr, "        |ous probabilities (37,56,70,56,37 over 256).  There are 5^5  |\n");
            strcat(outstr, "        |possible 5-letter words, and from a string of 256,000 (over- |\n");
            strcat(outstr, "        |lapping) 5-letter words, counts are made on the frequencies  |\n");
            strcat(outstr, "        |for each word.   The quadratic form in the weak inverse of   |\n");
            strcat(outstr, "        |the covariance matrix of the cell counts provides a chisquare|\n");
            strcat(outstr, "        |test: Q5-Q4, the difference of the naive Pearson sums of     |\n");
            strcat(outstr, "        |(OBS-EXP)^2/EXP on counts for 5- and 4-letter cell counts.   |\n");
            strcat(outstr, "        |-------------------------------------------------------------|\n\n");
            printf(outstr);
            fprintf(outfile, outstr);
        }
        printf("\n                Test result COUNT-THE-1's in bytes");
        fprintf(outfile, "\n                Test result COUNT-THE-1's in bytes");
        if (strlen(rngname) > 0)
        {
            printf(" for %s", rngname);
            fprintf(outfile, " for %s", rngname);
        }
        printf("\n");
        fprintf(outfile, "\n");
    }
    return;
}

/* type "stream" (use small case and don't forget the quotation mark) to test
   a stream of bytes. type "specific" to test specific bytes */
void cnt1s(unsigned long (*rng)(), void (*restart_rng)(), char *test, char *rngname)
{
    int minrns=256004;
    int rt=24;

    counter no_wds=256000;

    char *s="bits used";

    if(strncmp(test, "stream", 2)==0){
        rt = -1;
        s = "         ";
        no_wds = 2560000;
        minrns = 640001;
    }

    cnt_ttl(test, rngname);

    printf("          (Degrees of freedom: 5^4-5^3=2500; sample size: %lu)\n\n", no_wds);
    fprintf(outfile, "          (Degrees of freedom: 5^4-5^3=2500; sample size: %lu)\n\n", no_wds);
    printf("        %s       chisquare       z-score         p-value\n", s);
    fprintf(outfile, "        %s       chisquare       z-score         p-value\n", s);

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    do{
        cnt_stat(rng, restart_rng, no_wds, test, rt);
        --rt;
    }
    while(rt>=0);

    return;
}


#include "header.h"

/*print the title*/
void monky_ttl(char *test, char *rngname)
{
    char outstr[2000]="";

    if (terse == 0)
    {
        switch( test[1] )
        {
        case 'P':
        {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |        OPSO means Overlapping-Pairs-Sparse-Occupancy        |\n");
        strcat(outstr, "        |The OPSO test considers 2-letter words from an alphabet of   |\n");
        strcat(outstr, "        |1024 letters.  Each letter is determined by a specified ten  |\n");
        strcat(outstr, "        |bits from a 32-bit integer in the sequence to be tested. OPSO|\n");
        strcat(outstr, "        |generates  2^21 (overlapping) 2-letter words  (from 2^21+1   |\n");
        strcat(outstr, "        |\"keystrokes\")  and counts the number of missing words---that |\n");
        strcat(outstr, "        |is,2-letter words which do not appear in the entire sequence.|\n");
        strcat(outstr, "        |That count should be very close to normally distributed with |\n");
        strcat(outstr, "        |mean 141,909, sigma 290. Thus (missingwrds-141909)/290 should|\n");
        strcat(outstr, "        |be a standard normal variable. The OPSO test takes 32 bits at|\n");
        strcat(outstr, "        |a time from the test file and uses a designated set of ten   |\n");
        strcat(outstr, "        |consecutive bits. It then restarts the file for the next de- |\n");
        strcat(outstr, "        |signated 10 bits, and so on.                                 |\n");
        strcat(outstr, "        |------------------------------------------------------------ |\n\n");
        break;
        }

        case 'Q':
        {
        strcat(outstr, "\n        |------------------------------------------------------------ |\n");
        strcat(outstr, "        |    OQSO means Overlapping-Quadruples-Sparse-Occupancy       |\n");
        strcat(outstr, "        |  The test OQSO is similar, except that it considers 4-letter|\n");
        strcat(outstr, "        |words from an alphabet of 32 letters, each letter determined |\n");
        strcat(outstr, "        |by a designated string of 5 consecutive bits from the test   |\n");
        strcat(outstr, "        |file, elements of which are assumed 32-bit random integers.  |\n");
        strcat(outstr, "        |The mean number of missing words in a sequence of 2^21 four- |\n");
        strcat(outstr, "        |letter words,  (2^21+3 \"keystrokes\"), is again 141909, with  |\n");
        strcat(outstr, "        |sigma = 295.  The mean is based on theory; sigma comes from  |\n");
        strcat(outstr, "        |extensive simulation.                                        |\n");
        strcat(outstr, "        |------------------------------------------------------------ |\n");
        break;
        }

        case 'N':
        {
        strcat(outstr, "\n        |------------------------------------------------------------ |\n");
        strcat(outstr, "        |    The DNA test considers an alphabet of 4 letters: C,G,A,T,|\n");
        strcat(outstr, "        |determined by two designated bits in the sequence of random  |\n");
        strcat(outstr, "        |integers being tested.  It considers 10-letter words, so that|\n");
        strcat(outstr, "        |as in OPSO and OQSO, there are 2^20 possible words, and the  |\n");
        strcat(outstr, "        |mean number of missing words from a string of 2^21  (over-   |\n");
        strcat(outstr, "        |lapping)  10-letter  words (2^21+9 \"keystrokes\") is 141909.  |\n");
        strcat(outstr, "        |The standard deviation sigma=339 was determined as for OQSO  |\n");
        strcat(outstr, "        |by simulation.  (Sigma for OPSO, 290, is the true value (to  |\n");
        strcat(outstr, "        |three places), not determined by simulation.                 |\n");
        strcat(outstr, "        |------------------------------------------------------------ |\n");
        break;
        }

        default:
            strcat(outstr, "Wrong specification!!!");
            printf(outstr);
            fprintf(outfile, outstr);
            exit(0);
        }

        printf(outstr);
        fprintf(outfile, outstr);
    }
    printf("                           %s test", test);
    fprintf(outfile, "                           %s test", test);
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n\n        Bits used       No. missing words");
    fprintf(outfile, "\n\n        Bits used       No. missing words");
    printf("       z-score         p-value\n");
    fprintf(outfile, "       z-score         p-value\n");

    return;
}

/* get a word from specific bits */
unsigned long get_w(unsigned long (*rng)(), short bits_pl, int rt)
{
    static int flag=-1, ltrs_pw;
    static unsigned long wd, maskltr;
    short i;

    wd <<= bits_pl;

    if(flag!=rt){
        flag=rt;
        maskltr=pow(2,bits_pl)-1;
        ltrs_pw=20/bits_pl;

        for(i=1; i<ltrs_pw; ++i){
            wd+=( (rng()>>rt) & maskltr ) ;
            wd <<= bits_pl;
        }
    }

    wd+=( (rng()>>rt) & maskltr ) ;

    /* 1048575=2**20-1 */
    return (wd & 1048575);
}


void monky_stat(unsigned long (*rng)(), void (*restart_rng)(), char *test, int no_tests)
{
    int minrns=0;
    const real bits_pw=20, mean=pow(2, bits_pw)*exp(-2);
    const counter dim=pow(2, bits_pw-5);

    register unsigned long j, u, l, wd;

    unsigned long maskbit[32];
    counter k, rt=0, bits_pl=0, no_wds=pow(2, bits_pw+1);
    counter no_mswds, *wds;
    int i;

    real std=0.0, z, pvalue;

    switch(test[1]){
    case 'I':
        rt=33;
        break;
    case 'P':
        bits_pl=10;
        std=290;
        minrns = 2097153;
        break;
    case 'Q':
        bits_pl=5;
        std=295;
        minrns = 2097155;
        break;
    case 'N':
        bits_pl=2;
        std=339;
        minrns = 2097161;
        break;
    default :
        break;
    }

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    for(j=0; j<32; ++j){
        maskbit[j]=pow(2,j);
    }

    wds=(counter*)malloc(dim*sizeof(counter));

    do{
        for(i=1; i<=no_tests; ++i){
            for(j=0; j<dim; ++j){
                wds[j]=0;
            }

            for(j=1; j<=no_wds; ++j){
                wd = get_w(rng, bits_pl, rt);
                l = wd & 31;
                u = wd >> 5;
                wds[u] |= maskbit[l];
            }

            /*count no. of empty cells (=no. missing words)*/
            no_mswds=0;
            for(j=0; j<dim; ++j){
                for(k=0; k<32; ++k){
                    if( (wds[j] & maskbit[k]) == 0 ) ++no_mswds;
                }
            }

            z=(no_mswds-mean)/std;
            printf("        %-2lu to %-2lu                %-8lu", 33-rt-bits_pl, 32-rt, no_mswds);
            fprintf(outfile, "        %-2lu to %-2lu                %-8lu", 33-rt-bits_pl, 32-rt, no_mswds);
            pvalue = 1.0-cPhi(z);
            printf(" %14.4f         %f\n", z, pvalue);
            fprintf(outfile, " %14.4f         %f\n", z, pvalue);
            if (overall.pknt < overall.max) {
                overall.pval[overall.pknt] = pvalue;
                overall.pknt++;
            }

        }

        //uni("close");
	restart_rng();
        ++rt;
    }
    while(rt<=32-bits_pl);

    free(wds);

    printf("        ------------------------------");
    fprintf(outfile, "        ------------------------------");
    printf("-----------------------------------\n");
    fprintf(outfile, "-----------------------------------\n");

    return;
}

/* type "OPSO" for OPSO test and so on */
void monky(unsigned long (*rng)(), void (*restart_rng)(), char *test, char *rngname)
{
    const int no_tests=1;


    monky_ttl(test, rngname);

    monky_stat(rng, restart_rng, test, no_tests);

    return;

}


#include "header.h"
#include "macro.h"

void craptest1(unsigned long (*rng)(), char *rngname)
{
    const int minrns=1352588;
    const counter no_games=200000;

    register counter i, win, no_win=0, no_throw;
    register int out_1st, out_nxt;
    counter f[21];
    real Ef[21], sum, mean, std, t, pvalue_w, pvalue_th;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |This the CRAPS TEST.  It plays 200,000 games of craps, counts|\n");
        strcat(outstr, "        |the number of wins and the number of throws necessary to end |\n");
        strcat(outstr, "        |each game.  The number of wins should be (very close to) a   |\n");
        strcat(outstr, "        |normal with mean 200000p and variance 200000p(1-p), and      |\n");
        strcat(outstr, "        |p=244/495.  Throws necessary to complete the game can vary   |\n");
        strcat(outstr, "        |from 1 to infinity, but counts for all>21 are lumped with 21.|\n");
        strcat(outstr, "        |A chi-square test is made on the no.-of-throws cell counts.  |\n");
        strcat(outstr, "        |Each 32-bit integer from the test file provides the value for|\n");
        strcat(outstr, "        |the throw of a die, by floating to [0,1), multiplying by 6   |\n");
        strcat(outstr, "        |and taking 1 plus the integer part of the result.            |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    /*compute the expected frequencies*/
    sum=Ef[0]=1/3.;
    for(i=1; i<20; ++i){
        f[i]=0;
        Ef[i]=(27*pow(27/36.,i-1)+40*pow(26/36.,i-1)+55*pow(25/36.,i-1))/648;
        sum+=Ef[i];
    }
    Ef[20]=1.-sum;
    f[0]=f[20]=0;

    /*playing the games*/
#define DIE   1 + (int)( 6* (rng()/UNIMAX) )
#define GAME_OVER  {++f[MIN(20,no_throw)]; no_win+=win;}

    for(i=1; i<=no_games; ++i){
        out_1st=DIE+DIE;
        no_throw=0;

        if(out_1st==7 || out_1st==11){
            win=1;
            GAME_OVER
                continue;
        }

        if( out_1st==2 || out_1st==3 || out_1st==12){
            win=0;
            GAME_OVER
                continue;
        }

        for( ; ; ){
            out_nxt=DIE+DIE;
            ++no_throw;
            if(out_nxt==7){
                win=0;
                GAME_OVER
                    break;
            }

            if(out_nxt==out_1st){
                win=1;
                GAME_OVER
                    break;
            }
        }
    }
    //uni("close");

    mean=244*no_games/495.;
    std=sqrt(mean*251/495.);
    t=(no_win-mean)/std;

    printf("                RESULTS OF CRAPS TEST");
    fprintf(outfile, "                RESULTS OF CRAPS TEST");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n        No. of wins:  Observed  Expected\n");
    fprintf(outfile, "\n        No. of wins:  Observed  Expected\n");
    printf("                         %lu        %8.1f\n", no_win, mean);
    fprintf(outfile, "                         %lu        %8.1f\n", no_win, mean);

    pvalue_w=1.0-cPhi(t);
    printf("                z-score=%6.3f, pvalue=%7.5f\n", t, pvalue_w);
    fprintf(outfile, "                z-score=%6.3f, pvalue=%7.5f\n", t, pvalue_w);

    printf("\n        Analysis of Throws-per-Game:\n");
    fprintf(outfile, "\n        Analysis of Throws-per-Game:\n");

    printf("\n        Throws  Observed        Expected        Chisq    Sum of (O-E)^2/E\n");
    fprintf(outfile, "\n        Throws  Observed        Expected        Chisq    Sum of (O-E)^2/E\n");


    /* compute chi-square */
    sum=0;
    for(i=0; i<21; ++i){
        mean=no_games*Ef[i];
        t=(f[i]-mean)*(f[i]-mean)/mean;
        sum+=t;
        printf("        %-2lu      %-10lu      %-10.1f",i+1, f[i], mean);
        fprintf(outfile, "        %-2lu      %-10lu      %-10.1f",i+1, f[i], mean);
        printf("%11.3f           %.3f\n", t, sum);
        fprintf(outfile, "%11.3f           %.3f\n", t, sum);
    }

    //pvalue_th=1-Chisq(20,sum);
    //pvalue_th=1-ginc(10.0,sum/2.0);
    pvalue_th=ginc(10.0,sum/2.0);
    printf("\n        Chisq=%7.2f for 20 degrees of freedom, ", sum);
    fprintf(outfile, "\n        Chisq=%7.2f for 20 degrees of freedom, ", sum);
    printf("p=%8.5f\n", pvalue_th);
    fprintf(outfile, "p=%8.5f\n", pvalue_th);

    printf("\n                SUMMARY of craptest\n");
    fprintf(outfile, "\n                SUMMARY of craptest\n");
    printf("         p-value for no. of wins: %.6f\n", pvalue_w);
    fprintf(outfile, "         p-value for no. of wins: %.6f\n", pvalue_w);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue_w;
        overall.pknt++;
    }

    printf("         p-value for throws/game: %.6f\n", pvalue_th);
    fprintf(outfile, "         p-value for throws/game: %.6f\n", pvalue_th);
    printf("        _____________________________________________________________\n\n");
    fprintf(outfile, "        _____________________________________________________________\n\n");
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue_th;
        overall.pknt++;
    }


    return;
}



#include "header.h"
#include "macro.h"

int playdie(unsigned long(*rng)())
{
    int die;
    do
    {
       die = rng() & 7;
    } while (die < 1 || die > 6);
    return die;
}

void craptest2(unsigned long (*rng)(), char *rngname)
{
    const int minrns=1803451;
    const counter no_games=200000;

    register counter i, win, no_win=0, no_throw;
    register int out_1st, out_nxt;
    counter f[21];
    real Ef[21], sum, mean, std, t, pvalue_w, pvalue_th;
    char outstr[2000]="";

    if (terse == 0)
    {
        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |This is the CRAPS TEST with different dice. Each die value is|\n");
        strcat(outstr, "        |determined by the rightmost three bits of the 32-bit random  |\n");
        strcat(outstr, "        |integer; values 1 to 6 are accepted, others rejected.  As in |\n");
        strcat(outstr, "        |the first test, 200,000 games of craps are played, counting  |\n");
        strcat(outstr, "        |the number of wins and the number of throws necessary to end |\n");
        strcat(outstr, "        |each game.  The number of wins should be (very close to) a   |\n");
        strcat(outstr, "        |normal with mean 200000p and variance 200000p(1-p), and      |\n");
        strcat(outstr, "        |p=244/495.  Throws necessary to complete the game can vary   |\n");
        strcat(outstr, "        |from 1 to infinity, but counts for all>21 are lumped with 21.|\n");
        strcat(outstr, "        |A chi-square test is made on the no.-of-throws cell counts.  |\n");
        strcat(outstr, "        |-------------------------------------------------------------|\n\n");
        printf(outstr);
        fprintf(outfile, outstr);
    }

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    /*compute the expected frequencies*/
    sum=Ef[0]=1/3.;
    for(i=1; i<20; ++i){
        f[i]=0;
        Ef[i]=(27*pow(27/36.,i-1)+40*pow(26/36.,i-1)+55*pow(25/36.,i-1))/648;
        sum+=Ef[i];
    }
    Ef[20]=1.-sum;
    f[0]=f[20]=0;

    /*playing the games*/

    for(i=1; i<=no_games; ++i){
        out_1st=playdie(rng)+playdie(rng);
        no_throw=0;

        if(out_1st==7 || out_1st==11){
            win=1;
            GAME_OVER
                continue;
        }

        if( out_1st==2 || out_1st==3 || out_1st==12){
            win=0;
            GAME_OVER
                continue;
        }

        for( ; ; ){
            out_nxt=playdie(rng)+playdie(rng);
            ++no_throw;
            if(out_nxt==7){
                win=0;
                GAME_OVER
                    break;
            }

            if(out_nxt==out_1st){
                win=1;
                GAME_OVER
                    break;
            }
        }
    }
    //uni("close");

    mean=244*no_games/495.;
    std=sqrt(mean*251/495.);
    t=(no_win-mean)/std;

    printf("                RESULTS OF CRAPS TEST2");
    fprintf(outfile, "                RESULTS OF CRAPS TEST2");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf("\n        No. of wins:  Observed  Expected\n");
    fprintf(outfile, "\n        No. of wins:  Observed  Expected\n");
    printf("                         %lu        %8.1f\n", no_win, mean);
    fprintf(outfile, "                         %lu        %8.1f\n", no_win, mean);

    pvalue_w=1.0-cPhi(t);
    printf("                z-score=%6.3f, pvalue=%7.5f\n", t, pvalue_w);
    fprintf(outfile, "                z-score=%6.3f, pvalue=%7.5f\n", t, pvalue_w);

    printf("\n        Analysis of Throws-per-Game:\n");
    fprintf(outfile, "\n        Analysis of Throws-per-Game:\n");

    printf("\n        Throws  Observed        Expected        Chisq    Sum of (O-E)^2/E\n");
    fprintf(outfile, "\n        Throws  Observed        Expected        Chisq    Sum of (O-E)^2/E\n");


    /* compute chi-square */
    sum=0;
    for(i=0; i<21; ++i){
        mean=no_games*Ef[i];
        t=(f[i]-mean)*(f[i]-mean)/mean;
        sum+=t;
        printf("        %-2lu      %-10lu      %-10.1f",i+1, f[i], mean);
        fprintf(outfile, "        %-2lu      %-10lu      %-10.1f",i+1, f[i], mean);
        printf("      %.3f           %.3f\n", t, sum);
        fprintf(outfile, "      %.3f           %.3f\n", t, sum);
    }

    //pvalue_th=1-Chisq(20,sum);
    //pvalue_th=1-ginc(10.0,sum/2.0);
    pvalue_th=ginc(10.0,sum/2.0);
    printf("\n        Chisq=%7.2f for 20 degrees of freedom, ", sum);
    fprintf(outfile, "\n        Chisq=%7.2f for 20 degrees of freedom, ", sum);
    printf("p=%8.5f\n", pvalue_th);
    fprintf(outfile, "p=%8.5f\n", pvalue_th);

    printf("\n                SUMMARY of craptest\n");
    fprintf(outfile, "\n                SUMMARY of craptest\n");
    printf("         p-value for no. of wins: %.6f\n", pvalue_w);
    fprintf(outfile, "         p-value for no. of wins: %.6f\n", pvalue_w);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue_w;
        overall.pknt++;
    }

    printf("         p-value for throws/game: %.6f\n", pvalue_th);
    fprintf(outfile, "         p-value for throws/game: %.6f\n", pvalue_th);
    printf("        _____________________________________________________________\n\n");
    fprintf(outfile, "        _____________________________________________________________\n\n");
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue_th;
        overall.pknt++;
    }


    return;
}




#include <stdio.h>
#include <math.h>
#include "header.h"

#define IUNI cong()
unsigned long cong(){
    static unsigned long j=123456789;
    j=69069*j+12345;
    return j;
}

//test for lengths of 100,000 runs up and runs down
#define trm(x,e) ( ((x)-(e))*((x)-(e))/(e) )

void updown(unsigned long (*rng)(), char *rngname)
{
    const int minrns=689455;
    char outstr[2000]="";

    unsigned long i,k,n1=0,n2=0,x,y,z,n=100000,rngs=0;
    int Up[] ={
        0,0,0,0,0,0,0,0,0,0,0,0    };
    int Dwn[]={
        0,0,0,0,0,0,0,0,0,0,0,0    };
    double E[]={
        0,0,66666.67,25000.,6666.67,1388.89,
        238.0952,34.72,4.96    };
    double pup,pdwn,e,sup=0.,sdwn=0.;

    if (terse == 0) {
        strcat(outstr, "\n        |----------------------------------------------------------|\n");
        strcat(outstr, "        |This is the UP-DOWN RUNS test. An up-run of length n has  |\n");
        strcat(outstr, "        |x_1<...<x_n and x_n>x_(n+1), while a down-run of length n |\n");
        strcat(outstr, "        |has x_1>...>x_n and x_n<x_(n+1). The value that ends a run|\n");
        strcat(outstr, "        |is not part of the run that follows, so a long sequence of|\n");
        strcat(outstr, "        |numbers contains independent runs, up or down, of length k|\n");
        strcat(outstr, "        |with probability 2*k/(k+1)!. This test generates values   |\n");
        strcat(outstr, "        |until 100,000 up- and 100,000 down-runs are found, then it|\n");
        strcat(outstr, "        |tests to see of the frequencies of lengths for 100,000 of |\n");
        strcat(outstr, "        |each type are consistent with underlying theory. It also  |\n");
        strcat(outstr, "        |tests to see if the number of values needed to get 100,000|\n");
        strcat(outstr, "        |of each type is consistent with theory.                   |\n");
        strcat(outstr, "        |----------------------------------------------------------|\n");
    }

    strcat(outstr, "\nTest for lengths of runs up and runs down, 100,000 each");
    if (strlen(rngname) > 0)
    {
        strcat(outstr, " for ");
        strcat(outstr, rngname);
    }
    strcat(outstr, ":\n(for k>=2, the prob. of a run of length k is 2*k/(k+1)!)\n");
    strcat(outstr, "Length  Expected        UpRuns   (O-E)^2/E  DownRuns (O-E)^2/E\n");
    printf(outstr);
    fprintf(outfile, outstr);

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }

    do
        {
        x=rng();
        y=rng();
        z=rng();
        k=2;
        rngs+=3;
        if (x<y)
        {
            n1++;
            if (n1<n)
            {
                while (y<z)
                {
                    k++;
                    y=z;
                    z=rng();
                    rngs++;
                }
                if(k>8)
                    k=8;
                Up[k]++;
            }
        }
        else
        {
            n2++;
            if (n2<n)
            {
                while (y>z)
                {
                    k++;
                    y=z;
                    z=rng();
                    rngs++;
                }
                if(k>8)
                    k=8;
                Dwn[k]++;
            }
        }
    }
    while (n1<=n || n2<=n);
    i=2;
    for (k=2;k<=8;k++)
    {
        sup+=trm(Up[k],E[k]);
        sdwn+=trm(Dwn[k],E[k]);
        printf("%3lu %12.2f %13d %8.2f %11d %6.2f\n",
        k,E[k],Up[k],trm(Up[k],E[k]),Dwn[k],trm(Dwn[k],E[k]));
        fprintf(outfile, "%3lu %12.2f %13d %8.2f %11d %6.2f\n",
        k,E[k],Up[k],trm(Up[k],E[k]),Dwn[k],trm(Dwn[k],E[k]));
    }
    sup=.5*sup;
    sdwn=.5*sdwn;
    pup=1.-exp(-sup)*(1+sup+.5*sup*sup);
    pdwn=1.-exp(-sdwn)*(1+sdwn+.5*sdwn*sdwn);
    printf("                        p=%7.5f            p=%7.5f\n",pup,pdwn);
    fprintf(outfile, "                        p=%7.5f            p=%7.5f\n",pup,pdwn);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pup;
        overall.pknt++;
    }
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pdwn;
        overall.pknt++;
    }
    e=(rngs-688403.)/860.;
    e=.5+.5*sqrt(1.-exp(-.623*e*e));
    if(rngs<688403) e=1.-e;
    printf(" Number of rngs required: %lu, p-value: %6.3f\n\n",rngs,e);
    fprintf(outfile, " Number of rngs required: %lu, p-value: %6.3f\n\n",rngs,e);
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = e;
        overall.pknt++;
    }

}//endproc

#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "header.h"

int compi(const void *i, const void *j) //compare function for qsort
{

        if ( *(unsigned long int *)i < *(unsigned long int *)j )
        return -1;

        if ( *(unsigned long int *)i > *(unsigned long int *)j )
        return 1;

        return 0;

}


void bday2(unsigned long (*rng)(), char *rngname)
{

    const int minrns=2048000;
    int i,j,k,m=4096;

    unsigned long t[4096],obs[11]={
    0,0,0,0,0,0,0,0,0,0,0    };

    double w,x,ex[11],v=0.;

    char outstr[2000]="";


    if (terse == 0)
    {

        strcat(outstr, "\n        |-------------------------------------------------------------|\n");
        strcat(outstr, "        |         This is the \"tough\" BIRTHDAY SPACINGS TEST          |\n");
        strcat(outstr, "        |Choose 4096 birthdays in a \"year\" of 2^32 days. Thus each    |\n");
        strcat(outstr, "        |birthday is a 32-bit integer and the test uses 2^12 of them, |\n");
        strcat(outstr, "        |so that j, the number of duplicate spacings, is asympotically|\n");
        strcat(outstr, "        |Poisson distributed with lambda=4 .  Generators that pass the|\n");
        strcat(outstr, "        |earlier tests for m=1024 and n=2^24 often fail this test, yet|\n");
        strcat(outstr, "        |those that pass this test seem to pass the \"weaker\" test.    |\n");
        strcat(outstr, "        |Each set of 4096 birthdays provide a Poisson variate j, and  |\n");
        strcat(outstr, "        |500 such j's lead to a chisquare test to see if the result   |\n");
        strcat(outstr, "        |is consistent with the Poisson distribution with lambda=16.  |\n");
        strcat(outstr, "        |------------------------------------------------------------ |\n\n");
        printf(outstr);
        fprintf(outfile, outstr);

    }

    printf("        Tough bday spacings test");
    fprintf(outfile, "        Tough bday spacings test");
    if (strlen(rngname) > 0)
    {
        printf(" for %s", rngname);
        fprintf(outfile, " for %s", rngname);
    }
    printf(": 4096 birthdays, year=2^32 days\n");
    fprintf(outfile, ": 4096 birthdays, year=2^32 days\n");

    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


        for(k=1; k<=500; k++)
        {//loop for sample of size 500
            for(i=0; i<m; i++)
            t[i]=rng(); //get 4096 IUNI's
            qsort(t,m,sizeof(long),compi); //  sort them
            for(i=m-1; i>0; i--)
              t[i]=t[i]-t[i-1]; // get spacings
            qsort(t,m,sizeof(long),compi);  // sort spacings
            j=0;
            for(i=1; i<m; i++)
             j=j+(t[i]==t[i-1]) ;
            if(j>10)
              j=10;
            obs[j]++;      // count duplicate spacings
          }// end  sample of 500 loop

          strcpy(outstr, "           Table of Expected vs. Observed counts:\n");
          printf(outstr);
          fprintf(outfile, outstr);
          ex[0]=500.*exp(-4.); ex[10]=500.*.008132242;
          for(i=1;i<10;i++)
            ex[i]=4.*ex[i-1]/i;
          strcpy(outstr, "Duplicates   0");
          printf(outstr);
          fprintf(outfile, outstr);
          for(i=1;i<10;i++)
          {
            printf("%6.0f",i+0.);
            fprintf(outfile, "%6.0f",i+0.);
          }
          printf("   >=10\n");
          fprintf(outfile, "   >=10\n");
          printf("Expected ");
          fprintf(outfile, "Expected ");
          for(i=0;i<10;i++)
          {
            printf("%6.1f",ex[i]);
            fprintf(outfile, "%6.1f",ex[i]);
          }
          printf("%6.1f\n",ex[10]);
          fprintf(outfile, "%6.1f\n",ex[10]);
          printf("%8s","Observed");
          fprintf(outfile, "%8s","Observed");
          for(i=0;i<10;i++)
          {
            printf("%6.0f",obs[i]+0.0);
            fprintf(outfile, "%6.0f",obs[i]+0.0);
          }
          printf("%6.0f\n",obs[10]+0.0);
          fprintf(outfile, "%6.0f\n",obs[10]+0.0);
          printf("%9s","(O-E)^2/E");
          fprintf(outfile, "%9s","(O-E)^2/E");
          for(i=0;i<11;i++)
          {
            x= (obs[i]-ex[i])*(obs[i]-ex[i])/ex[i];
            v+=x;
            printf("%6.1f",x);
            fprintf(outfile, "%6.1f",x);
          }

          x=.5*v;
          w=24.+(24.+(12.+(4.+x)*x)*x)*x;
          w=1.-exp(-x)*w/24.;
          printf("\n      \
          Birthday Spacings: Sum(O-E)^2/E=%7.3f, p=%6.3f\n\n",v,w);
          fprintf(outfile, "\n      \
          Birthday Spacings: Sum(O-E)^2/E=%7.3f, p=%6.3f\n\n",v,w);

        if (overall.pknt < overall.max) {
            overall.pval[overall.pknt] = w;
            overall.pknt++;
    }

} // end bday


#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "header.h"



void gcd(unsigned long (*rng)(), char *rngname)
{ //gcd Test, n pairs of IUNI's
    const int minrns=20000000;
    unsigned long n=10000000;
    double s,ch32,ch99,e,r=1.0e-10, pvalue;
    unsigned long u, v, w, i, k, t[47], gcd[101];
    unsigned long kp[36]=\
        {0,0,0,5506,29532,144541,590691,2065333,6277273,16797273,39964829,\
         85160313,163520964,284315128,449367802,647663189,853365977,1030017639,\
         1140689999,1160424679,1085307890,933657875,738971259,538010076,360199303,\
         221583256,125137422,64787412,30697488,13285746,5238570,1876493,608568,\
         177920,46632,13674};

    char str[2000]="";

    if (terse == 0)
    {
        strcat(str,"\n        |-----------------------------------------------------------|\n");
        strcat(str,"        |This is the GCD TEST.   Let the (32-bit) RNG produce two   |\n");
        strcat(str,"        |successive integers u,v.  Use Euclids algorithm to find the|\n");
        strcat(str,"        |gcd, say x, of u and v. Let k be the number of steps needed|\n");
        strcat(str,"        |to get x.   Then k is approximately binomial with p=.376   |\n");
        strcat(str,"        |and n=50,  while the distribution of x is very close to    |\n");
        strcat(str,"        |  Pr(x=i)=c/i^2, with c=6/pi^2.   The gcd test uses ten    |\n");
        strcat(str,"        |million such pairs u,v to see if the resulting frequencies |\n");
        strcat(str,"        |of k's and x's are consistent with the above distributions.|\n");
        strcat(str,"        |Congruential RNG's---even those with prime modulus---fail  |\n");
        strcat(str,"        |this test for the distribution of k, the number of steps,  |\n");
        strcat(str,"        |and often for the distribution of gcd values x as well.    |\n");
        strcat(str,"        |-----------------------------------------------------------|\n\n");
        printf(str);
        fprintf(outfile, str);
    }

    printf("                RESULTS OF GCD");
    fprintf(outfile, "                RESULTS OF GCD");
    if (strlen(rngname) > 0)
    {
        printf(" FOR %s", rngname);
        fprintf(outfile, " FOR %s", rngname);
    }
    printf("\n");
    fprintf(outfile, "\n");
    if (maxrnavail < minrns)
    {
        printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
        return;
    }


    for(i=1;i<101;i++)
    {
        gcd[i]=0;
        if(i<47)
          t[i]=0;
    }
    for (i=1; i<=n; i++)
    {
        k=0;
        do
        {
          u=rng();
          v=rng();
        } while (u==0 || v==0);
        do
        {

          w=u%v;
          u=v;
          v=w;
          k++;
        } while(v>0);
        if (u>100)
          u=100;
        gcd[u]++;
        if (k<3)
          k=3;
        if (k>35)
          k=35;
        t[k]++;
      }
      ch32=0.0;
      printf("Euclid's algorithm:\n");
      fprintf(outfile, "Euclid's algorithm:\n");
      for (i=3; i<=35; i++)
      {
        e=(r*kp[i])*n;s=(t[i]-e)*(t[i]-e)/e;ch32+=s;
      }
    // User: you may want to insert printf("%4d %6.3f %7.2f\n",i,s,ch32);
    //   in the above loop to see the (O-E)^2/E values and their sums
      pvalue = ginc(16., .5*ch32);
      printf(" p-value, steps to gcd:   %f\n", pvalue);
      fprintf(outfile, " p-value, steps to gcd:   %f\n", pvalue);
      if (overall.pknt < overall.max) {
          overall.pval[overall.pknt] = pvalue;
          overall.pknt++;
      }

      e=n*.61097691e-2; ch99=(gcd[100]-e)*(gcd[100]-e)/e;
      for (i=1; i<100; i++)
      {
        e=n*0.6079271/(i*i);
        s=(gcd[i]-e)*(gcd[i]-e)/e;
        ch99+=s;
      }
    // User: you may want to insert printf("%4d %6.3f %7.2f\n",i,s,ch99);
    //   in the above loop to see the (O-E)^2/E values and their sums

    pvalue = ginc(49.5,.5*ch99);
    printf(" p-value, dist. of gcd's: %f\n\n", pvalue);
    fprintf(outfile, " p-value, dist. of gcd's: %f\n\n", pvalue);

    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = pvalue;
        overall.pknt++;
    }

}

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

#include "header.h"





float ad32(float z)
{  // converts AD KS statistic into p-value, n=32
  float y;

  if(z<.5)
  {
    y=exp(-1.27*log(z));
    return( exp(.266-(.70025-(.009804-.000213*y)*y)*y));
  }
  if (z<1.)
    return ( (.53383+(1.65285-(1.988-.6634*z)*z)*z)*z-.21862 );
  if(z<2.)
    return ( .99987-.6616*exp(-1.0896*z)-.953*exp(-2.005*z)  );
    return( 1-.52686*exp(-1.05276*z)-.68053*exp(-1.62034*z) );
}

void gorilla(unsigned long (*rng)(), void (*resetrng)(), char *rngname)
{// begin gorilla
  const int minrns=67108889;
  unsigned int *t;
  float z,v,u[32], p;
  int s[256]={0}; // table for quick count-the-1's in a long stream
  unsigned long k,w,i,j,q,mask,m[32];
  unsigned long n=67108864;
  char outstr[2000]="";

  if (terse == 0)
  {
    strcat(outstr, "\n        |-----------------------------------------------------------|\n");
    strcat(outstr, "        |This is the GORILLA test, a strong version of the monkey   |\n");
    strcat(outstr, "        |tests that I developed in the 70's. It concerns strings    |\n");
    strcat(outstr, "        |formed from specified bits in 32-bit integers from the RNG.|\n");
    strcat(outstr, "        |We specify the bit position to be studied, from 0 to 31,   |\n");
    strcat(outstr, "        |say bit 3. Then we generate 67,108,889 (2^26+25) numbers   |\n");
    strcat(outstr, "        |from the generator and form a string of 2^26+25 bits by    |\n");
    strcat(outstr, "        |taking bit 3 from each of those numbers. In that string of |\n");
    strcat(outstr, "        |2^26+25 bits we count the number of 26-bit segments that   |\n");
    strcat(outstr, "        |do not appear. That count should be approximately normal   |\n");
    strcat(outstr, "        |with mean 24687971 and std. deviation 4170. This leads to  |\n");
    strcat(outstr, "        |a normal z-score and hence to a p-value. The test is       |\n");
    strcat(outstr, "        |applied for each bit position 0 (leftmost) to 31.          |\n");
    strcat(outstr, "        |(Some older tests use Fortran's 1-32 for most- to least-   |\n");
    strcat(outstr, "        |significant bits. Gorilla and newer tests use C's 0 to 31.)|\n");
    strcat(outstr, "        |-----------------------------------------------------------|\n\n");
  }
  strcat(outstr, " Gorilla test for 2^26 bits, positions 0 to 31");
  if (strlen(rngname) > 0)
  {
      strcat(outstr, " for ");
      strcat(outstr, rngname);
  }
  strcat(outstr, ":\n Note: lengthy test---for example, ~20 minutes for 850MHz PC\n");
  printf(outstr);
  fprintf(outfile, outstr);

  if (maxrnavail < minrns)
  {
      printf("Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
      fprintf(outfile, "Not enough random numbers for this test. Minimum is %d. The test is skipped.\n", minrns);
      return;
  }


  for(i=1; i<256; i++)
  {
    q=i;
    s[i]=1;
    while (q&=(q-1))
      s[i]++;
  } // set s table
  m[31]=1;
  for (i=31; i>0; i--)
    m[i-1]=2*m[i];                // set masks
  t = (unsigned int *) malloc(2097152*sizeof(unsigned int));
  if (t == NULL)
  {
    printf("No enough memory! Program aborted!!!\n");
    fprintf(outfile, "No enough memory! Program aborted!!!\n");
    exit(1);
  }
  for(k=0; k<32; k++)
  { //k loops thru bits 0,1,..31
    mask=m[k];         // mask set to bit k
    for(i=0; i<2097152; i++)
      t[i]=0;             //initialize t-array
    w=0;
    for (i=0; i<25; i++)
    {
      w = (w>>1);
      if (rng()&mask)
        w = w+(1<<25);
    }
    for(i=0; i<n; i++)
    { //i loop, gets 2^26 w's, sets bit in t[] for each
      w=(w>>1);
      if(rng()&mask)
        w=w+(1<<25);
      j=(w&2097151);
      t[j]=(t[j] | m[w>>21]);
    } //end i loop
//    printf("");
    w=0;
    for(i=0; i<2097152; i++)
    {
      j=t[i]; // loop to count 1's in t[] array
      w+= s[(j)&255]+s[(j>>8)&255]+s[(j>>16)&255]+s[(j>>24)&255];
    }        // end count loop
    z=((n-w)-24687971.)/4170.;    // convert counts to normal z-score
    v= (z>0.) ? 1./(1.+.33267*z) : 1./(1.-.33267*z);
    v=exp(-.5*z*z)*(.1740120799+(.3739278012*v-.04793993633)*v)*v;
    if(z>0)
      v=1.-v; u[k]=v;       // z-score converted to p-value
    if (overall.pknt < overall.max) {
        overall.pval[overall.pknt] = v;
        overall.pknt++;
    }
    if(k%8 == 0)
    {
      printf(" Bits %2lu to %2lu--->",k,k+7);
      fprintf(outfile, " Bits %2lu to %2lu--->",k,k+7);
    }
    printf( "%6.3f", v);
    fprintf(outfile, "%6.3f", v);
    if (k%8 == 7)
    {
      printf("\n");
      fprintf(outfile, "\n");
    }
    resetrng();
  }//end k loop
  free(t);
  // Now do KS test on 32 u's.  first, sort u's.
  for (i=0; i<31; i++)
  {
    for (j=0; j<31-i; j++)
      if (u[j+1] < u[j])
      {
        v=u[j];
       	u[j]=u[j+1];
       	u[j+1]=v;
      }
  }
  // calculate Anderson-Darling statistic
  z = -1024.;
  for (i=0; i<32; i++)
  {
    v=u[i]*(1.-u[31-i]);
    if (v<1.e-30)
      v=1.e-30;
    z=z-(i+i+1)*log((double)v);
  }
  p = ad32(z/32.);
  if (overall.pknt < overall.max) {
     overall.pval[overall.pknt] = p;
     overall.pknt++;
  }
  printf(" KS test for the above 32 p values: %6.3f\n\n", p);
  fprintf(outfile, " KS test for the above 32 p values: %6.3f\n\n", p);
}//end gorilla


#include "header.h"
#include "macro.h"

/*This test is based on a modified Kolmogorov-Smirnov method.
  The test-statistic is (FN(X)-X)**2/(X*(1-X)) (Anderson-Darling)
  where X is a uniform under null hypothesis. FN(X) is the empirical
  distribution of X.*/

/*c.d.f of Anderson-Darling statistic (a quick algorithm)*/
real AD(real z)
{
    if( z<.01 ) return 0;

    if( z<=2 ){
        return 2*exp(-1.2337/z)*(1+z/8-.04958*z*z/(1.325+z))/sqrt(z);
    }

    if( z<=4 ) return 1-.6621361*exp(-1.091638*z)-.95095*exp(-2.005138*z);

    if( 4<z ) return 1-.4938691*exp(-1.050321*z)-.5946335*exp(-1.527198*z);

    return -1; /*error indicator*/
}

real spline(real x, int n)
{
    real tmp=ABS(10*x+.5-n);

    if( n<7 ){
        if( tmp>1.5 ) return 0;
        if( tmp<=.5 ) return 1.5-2*tmp*tmp;
        else return 2.25-tmp*(3-tmp);
    }

    else switch(n){
    case 7:
        {
            if( x<=.8 || x>=1 ) return 0;
            else return 100*(x-.9)*(x-.9)-1;
        }
    case 8:
        {
            if( x<=0 || x>=.05 ) return 0;
            if( x<=.01 ) return -100*x;
            else return 25*(x-.05);
        }
    case 9:
        {
            if( x<=.98 || x>=1 ) return 0;
            else return .1-10*ABS(x-.99);
        }
    default:
        break;
    }

    return -100000; /*error indicator*/
}

real KStest( real *x, int dim)
{
    int fcmpr(const void *u1, const void *u2);
    /*
      int L[10][8]={ {40,46,37,34,27,24,20,20},
                     {88,59,43,37,29,27,20,22},
                     {92,63,48,41,30,30,25,24},
                     {82,59,42,37,26,28,26,22},
                     {62,48,33,30,23,23,22,18},
                     {49,34,22,20,16,17,17,12},
                     {17,17, 7, 8, 4, 7, 5, 1},
                     {40,18,19,14,16,13,10, 9},
                     {59,20,10, 4, 1, 1, 0,-1},
                     {41,43,36,112,15,95,32,58} };
    */
    int i;
    real pvalue, tmp, z=-dim*dim, epsilon=pow(10, -20);

    qsort(x,dim,sizeof(double),fcmpr);

    for(i=0; i<dim; ++i){
        tmp=x[i]*(1-x[dim-1-i]);
        tmp=MAX(epsilon,tmp);
        z-=(2*i+1)*log(tmp);
    }

    z/=dim;
    pvalue=1-AD(z);

    /*for(i=0; i<10; ++i) sum+=L[i][m]*sp(p, i)*.0001;

      if( dim>10 ) sum*=10./dim;

      return p+sum;???*/

    return pvalue;
}





#include "header.h"

#define DIM 4096

FILE *ranfile;
static int count=DIM, m;
static unsigned long uniran[DIM];
int maxrnavail=INT_MAX;

off_t fsize(char *name)
{
	struct stat stbuf;
	off_t size = 0;

	if (stat(name, &stbuf) == -1)
	{
		printf("fsize: can't access %s\n", name);
		return size;
	}
	size = stbuf.st_size;
	return size;
}



void RESTART_RNG()
{
    fseek(ranfile, 0, SEEK_SET);
    count = DIM;
}

/*read in a uniform random number from a file*/
/* Input DIM no. of unsigned integer from the file.

  */
unsigned long RNG()
{

    /* if (++count) == 0..DIM-1, return one no. in the buffer */
    if( (++count)<m )
    {
        return uniran[count];
    }

    /* The buffer is empty, input DIM nos */
    m = fread( uniran, sizeof(unsigned long), DIM , ranfile );
    if (m == 0)
    {
        printf("***** Not enough random numbers for testing *****\n");
        fprintf(outfile, "***** Not enough random numbers for testing *****\n");
        printf("***** The result could not be trusted *****\n");
        fprintf(outfile, "***** The result could not be trusted *****\n");
        exit(1);
    }

    count=0;

    return uniran[count];

}/* rng */
#include "header.h"
#include "macro.h"

/*gamma(z) when 2z is a integer*/
double G(double z)
{
    int tmp=2*z;

    if( tmp!=2*z || z==0 ) printf("Error in calling G(z)!!!");

    switch(tmp){
    case 1:
        return sqrt(PI);
    case 2:
        return 1;
    default:
        break;
    }

    return (z-1)*G(z-1);
}

int ucmpr( const void *i1, const void *i2)
{
    uniform *u1=(uniform*)i1, *u2=(uniform*)i2;

    if( *u1<*u2 ) return -1;
    if( *u1==*u2 ) return 0;

    return 1;
}

int fcmpr(const void *f1, const void *f2)
{
    real *u1=(real*)f1, *u2=(real*)f2;

    if( *u1<*u2 ) return -1;
    if( *u1==*u2 ) return 0;

    return 1;
}

/*show the bit-pattern of an integer*/
void showbit(int n)
{
    short int i, bit[32];
    int tmp=n;

    for(i=0; i<32; ++i){
        bit[i]=0;
        if(tmp<0) bit[i]=1;
        tmp*=2;
        printf("%d",bit[i]);
    }

    return;
}
#include <stdio.h>
#include <math.h>
#include "header.h"

double G(double z);



/*p.d.f of Poisson distribution*/
double Poisson(double lambda, int k)
{
    if(k==0) return exp(-lambda);

    return exp(-lambda)*pow(lambda, k)/G(k+1);
}
#include <stdio.h>
#include <stdlib.h>
#include <math.h>




double dlgamma(double a)
{
    //loggamma function using modified Lanczos series, March 1990 version******
        double z,lancz;

    z=a-1.;
    lancz=1.000000000178+(29249.5945797079+z*
        (30517.0640546116+z*(12860.9140634197+z*(
    2730.70944908458+z*(291.334201421932+z*12.458333324594)))))
        /((z+1)*(z+2)*(z+3)*(z+4)*(z+5)*(z+6));
    return (z+.5)*log(z+5.5)-z-4.581061466795+log(lancz);
}
/*
#define Phi(x) ( .5+(((x)>0.)-.5)*ginc(.5,.5*(x)*(x)) )
*/

double ginc(double a,double z) //incomplete gamma function
{
    int j,ps;
    double aa,p1,p2,q1,q2,v,s,g,t,p,q,w;

    if ( (a<1) && (z>20) )
        return (1.);
    if ( z>a+(10.+24/a)*sqrt(a) )
        return (1.);

    aa=a;
    if (a<1.)
        a=a+1.;
    ps=(a>z);
    if(ps)
    {
        p1=(a+1.)*exp(a*log(z)-z-dlgamma(a+1.));
        q1=a+1.-z;
        v=(a+2.)*((a+1.)*(a+3.)-(a-1.)*z);
        p2=v*p1;
        q2=v*q1+(a+3.)*z*z;
    }
    else
    {
        p1=z*exp((a-1.)*log(z)-z-dlgamma(a));
        p2=p1*(3.+z-a);
        q1=z+1.-a;
        q2=q1*(z+3.-a)+(a-1.);
    }
    s=1;
    g=1;
    for (j=2;j<301;j++)
    {
        if(ps)
        {
            t=a+(j+j+1);
            v=(t-1.)*(t*(t-2.)-(a-1.)*z);
            w=t*(t-4.)*(a+(j-1))*j*z*z;
        }
        else
        {
            v=(j+j+1)-a+z;
            w=j*(a-j);
        }
        p=v*p2+w*p1;
        q=v*q2+w*q1;
        s=g;
        g=p/q;
        if (fabs(g-s)/g < 1.e-12)
            break;
        p1=p2/p;
        q1=q2/p;
        q2=q/p;
        p2=1.;
    }
    //printf("%d %f",j,g," not within tolerance: 1e-10\n");
    if(!ps)
        g=1.-g;
    if(aa<1)
        g=g+exp(-z+aa*log(z)-dlgamma(a));
    return g;
}

/*
  double  Phi(double x)
{
#define dabs(x) ( (x) < 0 ? (-x) : (x) )
 double v[15]={
 1.253314137315500,.6556795424187985,.4213692292880545,
 .3045902987101033,.2366523829135607,.1928081047153158,
 .1623776608968675,.1401041834530502,.1231319632579329,
 .1097872825783083,.09902859647173193,.09017567550106468,
 .08276628650136917,.0764757610162485,.07106958053885211};
int i,j; double z,h,a,b,sum,pwr;
      j=dabs(x)+.5;
      if(j>14) j=14;
      z=j;
      h=dabs(x)-z;
      a=v[j];
      b=z*a-1.;
      pwr=1.;
      sum=a+h*b;
      for(i=2;i<=24-j;i+=2)
 {
 a=(a+z*b)/i; b=(b+z*a)/(i+1);
 pwr=pwr*h*h; sum=sum+pwr*(a+h*b);}
  sum=sum*exp(-.5*x*x-.918938533204672);
  if(x>=0) return (1.-sum);
  if(x<0) return sum;
}
*/

#include <stdio.h>
#include <math.h>
#include "macro.h"



double cPhi(double x)
{
    long double v[]={
        0.,.65567954241879847154L,
        .42136922928805447322L,.30459029871010329573L,.23665238291356067062L,
        .19280810471531576488L,.16237766089686746182L,.14010418345305024160L,
        .12313196325793229628L,.10978728257830829123L,
        .99028596471731921395e-1L,.90175675501064682280e-1L,
        .82766286501369177252e-1L,.76475761016248502993e-1L,
        .71069580538852107091e-1L,.66374235823250173591e-1L    };
    long double h,a,b,z,t=0,sum,pwr;
    int i,j;
    if (x>15.)
        return (0.);
    if (x<-15.)
        return (1.);

    j=fabs(x)+1.;
    z=j;
    h=fabs(x)-z;
    a=v[j];
    b=z*a-1.;
    pwr=1.;
    sum=a+h*b;
    for (i=2; i<60; i+=2)
    {
        a=(a+z*b)/i;
        b=(b+z*a)/(i+1);
        pwr=pwr*h*h;
        t=sum;
        sum=sum+pwr*(a+h*b);
        if (sum==t)
            break;
    }
    sum=sum*exp(-.5*x*x-.91893853320467274178L);
    if(x<0.)
        sum=1.-sum;
    return ((double) sum);
}
