#include "header.h"
#include "macro.h"

/* Define your random number routine and reset seed routine here */

// #define RNG myRNG
// #define RESTART_RNG resetRNG

unsigned long RNG();
void RESTART_RNG();

int terse = 0; /* default is FALSE */

FILE * outfile;

struct pvalstruct overall;

void do_test (char *option, char *rngdes)
{

    int i, status[17];

    for (i = 0; i < 17; ++i)
    {

        if (option[i] == '1')
            status[i] = i + 1;
        else
            status[i] = 0;
    }

    for (i = 0; i < 17; i++)
    {
        RESTART_RNG ();
        switch (status[i])
        {

        case 1:
            bday (RNG, RESTART_RNG, rngdes);

            bday2 (RNG, rngdes);
            break;

        case 2:
            gcd (RNG, rngdes);
            break;

        case 3:
            gorilla (RNG, RESTART_RNG, rngdes);
            break;

        case 4:
            operm5 (RNG, rngdes);
            break;

        case 5:
            binrnk (RNG, RESTART_RNG, "31x31", rngdes);

            binrnk (RNG, RESTART_RNG, "32x32", rngdes);
            break;

        case 6:
            binrnk (RNG, RESTART_RNG, "6x8", rngdes);
            break;

        case 7:
            bitst (RNG, rngdes);
            break;

        case 8:
            monky (RNG, RESTART_RNG, "OPSO", rngdes);

            monky (RNG, RESTART_RNG, "OQSO", rngdes);

            monky (RNG, RESTART_RNG, "DNA", rngdes);
            break;

        case 9:
            cnt1s (RNG, RESTART_RNG, "stream", rngdes);
            break;

        case 10:
            cnt1s (RNG, RESTART_RNG, "specific", rngdes);
            break;

        case 11:
            park (RNG, rngdes);
            break;

        case 12:
            mindist (RNG, rngdes);
            break;

        case 13:
            sphere (RNG, rngdes);
            break;

        case 14:
            squeez (RNG, rngdes);
            break;

        case 15:
            osum (RNG, rngdes);
            break;

        case 16:
            updown (RNG, rngdes);
            break;

        case 17:
            craptest1 (RNG, rngdes);
            RESTART_RNG ();
            craptest2 (RNG, rngdes);
            break;

        default:
            break;

        }

    }

}


void diehard (int prompt, char *infilename, char *rngname, char *option)
{

#ifndef RNG
    char filenotfound = 'y';
    char fn[256];
#endif
    char op[256];
    char rngdes[256]="";
    char outstr[2000] = "";

    if (terse == 0)
    {
        strcat (outstr, "\n                                NOTE\n");
        strcat (outstr,
        "        Most of the tests in DIEHARD return a p-value, which\n");
        strcat (outstr,
        "        should be uniform on [0,1) if the input file contains truly\n");
        strcat (outstr,
        "        independent random bits.   Those p-values are obtained by\n");
        strcat (outstr,
        "        p=F(X), where F is the assumed distribution of the sample\n");
        strcat (outstr,
        "        random variable X---often normal. But that assumed F is often \n");
        strcat (outstr,
        "        just an approximation, for which the fit will likely be worst\n");
        strcat (outstr,
        "        in the tails. Thus you should not be surprised with  occasion-\n");
        strcat (outstr,
        "        al p-values near 0 or 1, such as .0012 or .9983. When a bit\n");
        strcat (outstr,
        "        stream really FAILS BIG, you will get p`s of 0 or 1 to six \n");
        strcat (outstr,
        "        or more places.  By all means, do not, as a Statistician \n");
        strcat (outstr,
        "        might, think that a p < .025 or p> .975 means that the RNG\n");
        strcat (outstr,
        "        has \"failed the test at the .05 level\".  Such p`s happen\n");
        strcat (outstr,
        "        among the hundreds that DIEHARD produces, even with good RNGs.\n\n");
        strcat (outstr, "                 So keep in mind that \"p happens\"\n\n");
#ifndef RNG
        strcat (outstr, "        Enter the name of the file to be tested.\n");
        strcat (outstr,
        "        This must be a form=\"unformatted\",access=\"direct\" binary\n");
        strcat (outstr, "        file of about 10-12 million bytes.\n");
        strcat (outstr, "Enter file name: \n");
#endif
        printf (outstr);
        fprintf (outfile, outstr);
    }

#ifndef RNG
    while (filenotfound == 'y')
    {

        if (strlen (infilename) == 0)
        {
            fgets (infilename, 256, stdin);
        }
        sscanf (infilename, "%s", fn);

        if (strlen (fn) == 0)
        {
            return;
        }

        ranfile = fopen (fn, "rb");

        if (ranfile != NULL)
        {
            filenotfound = 'n';
        }
        else
        {
            printf ("File not found. Enter file name:\n");
            strcpy (infilename, "");
        }

    }

    maxrnavail = fsize(fn)/sizeof(int);
#endif

    if (prompt == 1 && strlen(rngname) == 0)
    {
#ifndef RNG
        printf("Enter RNG's name (Press Enter if want to be same as file name):\n");
#else
        printf("Enter RNG's name:\n");
#endif
        fgets(rngname, 256, stdin);
        sscanf (rngname, "%s", rngdes);
    }
    else
        strcpy(rngdes, rngname);
#ifndef RNG
    if (strlen(rngdes) == 0)
        strcpy(rngdes, fn);
#endif
    if (terse == 0)
    {
#ifndef RNG
        fprintf (outfile, "%s\n", fn);
#endif
        strcpy (outstr, "");
        strcat (outstr, "\n Which tests do you want to perform?\n");
        strcat (outstr, " For all tests, enter 17 1's:\n");
        strcat (outstr, "11111111111111111:\n");
        strcat (outstr, "To choose, say, tests 1, 3, 7, 14  enter:\n");
        strcat (outstr, "10100010000001000:\n");
        strcat (outstr, "\n                HERE ARE YOUR CHOICES:\n");
        strcat (outstr, "                1   Birthday Spacings\n");
        strcat (outstr, "                2   GCD\n");
        strcat (outstr, "                3   Gorilla\n");
        strcat (outstr, "                4   Overlapping Permutations\n");
        strcat (outstr, "                5   Ranks of 31x31 and 32x32 matrices\n");
        strcat (outstr, "                6   Ranks of 6x8 Matrices\n");
        strcat (outstr, "                7   Monkey Tests on 20-bit Words\n");
        strcat (outstr, "                8   Monkey Tests OPSO,OQSO,DNA\n");
        strcat (outstr, "                9   Count the 1`s in a Stream of Bytes\n");
        strcat (outstr, "                10  Count the 1`s in Specific Bytes\n");
        strcat (outstr, "                11  Parking Lot Test\n");
        strcat (outstr, "                12  Minimum Distance Test\n");
        strcat (outstr, "                13  Random Spheres Test\n");
        strcat (outstr, "                14  The Sqeeze Test\n");
        strcat (outstr, "                15  Overlapping Sums Test\n");
        strcat (outstr, "                16  Runs Up and Down Test\n");
        strcat (outstr, "                17  The Craps Test\n");
        strcat (outstr, "\n");
        strcat (outstr,
        " Enter your choices, 1's yes, 0's no using 17 columns:\n");
        strcat (outstr, "12345678901234567\n");
        printf (outstr);
        fprintf (outfile, outstr);

    }


    if (strlen (option) == 0)
        fgets (option, 20, stdin);
    sscanf (option, "%s", op);

    if (terse == 0)
        fprintf (outfile, "%s\n", op);

    do_test (op, rngdes);

}


void usage (char *command)
{
#ifndef RNG
    printf ("Usage: %s [-t] [[+n1 +n2 ...] | [-n1 -n2 ...]] [-o appendfile] [-s rngname] [infile]\n",
    command);
#else
    printf ("Usage: %s [-t] [[+n1 +n2 ...] | [-n1 -n2 ...]] [-o appendfile] [-s rngname]\n",
    command);
#endif

    exit (1);

}


int main (int argc, char **argv)
{

    char outfilename[256] = "result.txt";
    char infilename[256] = "";
    char option[256] = "";
    char rngname[256] = "";
    int mode = 0;
    int prompt = 1;
    int i, j;
    char outstr[1024] = "";

    real pvalue = 0;

    if (argc > 1)
    {
        prompt = 0;
        strcpy (option, "11111111111111111");
    }

    for (i = 1; i < argc; i++)
    {
        if (strncmp (argv[i], "-o", 2) == 0)
        {
	          i++;
            strcpy(outfilename, argv[i]);
      	}
        else if (strncmp (argv[i], "-t", 2) == 0)
            terse = 1; /* set it to TRUE */
        else if (strncmp (argv[i], "-s", 2) == 0)
        {
            i++;
            strcpy(rngname, argv[i]);
        }
        else if (strncmp (argv[i], "+", 1) == 0)
        {
            if (mode < 0)
                usage (argv[0]);
            if (mode == 0)
            {
                mode = 1;
                strcpy (option, "00000000000000000");
            }

            sscanf (argv[i], "%d", &j);

            if (j > 0 && j < 18)
                option[j - 1] = '1';

        }
        else if (strncmp (argv[i], "-", 1) == 0)
        {
            if (mode > 0)
                usage (argv[0]);
            if (mode == 0)
            {
                mode = -1;
            }

            sscanf (argv[i], "%d", &j);

            if (j < 0 && j > -18)
            {
                option[abs (j) - 1] = '0';
            }

        }
#ifndef RNG
        else if (isalpha (argv[i][0]))
            strcpy (infilename, argv[i]);
#endif
        else
            usage (argv[0]);

    }

    outfile = fopen (outfilename, "a");
    if (outfile == NULL)
    {
        printf ("Couldn't create the output file %s\n", outfilename);
        printf ("Program aborted!!!\n");
        exit (1);
    }

    overall.pknt = 0;
    overall.max = 4096;
    overall.pval = (real *)malloc(overall.max*sizeof(real));

    diehard (prompt, infilename, rngname, option);

    printf("\n\n                ***** TEST SUMMARY *****\n\n");
    fprintf(outfile, "\n\n                ***** TEST SUMMARY *****\n\n");
    printf("All p-values:\n");
    fprintf(outfile, "All p-values:\n");
    i = 0;
    while (i < overall.pknt) {
        for (j=0; i<overall.pknt && j<10; j++) {
	    printf("%5.4f,", overall.pval[i]);
	    fprintf(outfile, "%5.4f,", overall.pval[i]);
	    i++;
	}
	printf("\n");
	fprintf(outfile, "\n");
    }

    if (overall.pknt > 0)
        pvalue = KStest(overall.pval, overall.pknt);

    printf("\nOverall p-value after applying KStest on %d p-values = %f\n", overall.pknt, pvalue);
    fprintf(outfile,
   "\nOverall p-value after applying KStest on %d p-values = %f\n", overall.pknt, pvalue);

    strcat(outstr, "\nIn response to requests, we have provided a list of all the p-values\n");
    strcat(outstr, "produced by the tests you have chosen for this run. The individual\n");
    strcat(outstr, "p-values are supposed to be uniform in [0,1), but they are not necessarily\n");
    strcat(outstr, "independent. So even though we have applied a KSTEST to the accumulated\n");
    strcat(outstr, "p-values, the result is not necessarily---even if your file contains truly\n");
    strcat(outstr, "random bits---uniform in [0,1). But it is probably pretty close, so take\n");
    strcat(outstr, "that last p-value with a grain of salt. In particular, there may be some\n");
    strcat(outstr, "values so close to 0 or 1 that the tests they came from should be applied\n");
    strcat(outstr, "several more times, or new, related tests should be undertaken.\n");
    printf(outstr);
    fprintf(outfile, outstr);
    free(overall.pval);
    fclose (outfile);
    return 0;

}
