
#ifndef _HEADER_H_
#define _HEADER_H_

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <math.h>
#include <string.h>
#include <fcntl.h>
#include <limits.h>
#include <sys/stat.h>

#define DIM       4096
#define UNIMAX    4294967296.   /*pow(2,32)*/

typedef unsigned long uniform; 

typedef unsigned long counter;

typedef double real;

struct pvalstruct {
    int max;
    int pknt;
    real *pval;
};

extern struct pvalstruct overall;

extern int terse;
extern FILE *outfile;
extern FILE *ranfile;
extern int maxrnavail;


off_t fsize(char *filename);

double Phi(double z);

double cPhi(double z);

double chisq(int df, double chsq);

double Chisq(int df, double chsq);

double Chisq2(double d, double chsq);

double ginc(double d, double chsq);

double Poisson(double lambda, int k);

real KStest(real *x, int dim);

void bday (unsigned long (*rng) (), void (*restart_rng)(), char *rngname);

void bday2 (unsigned long (*rng) (), char *rngname);

void gcd (unsigned long (*rng) (), char *rngname);

void gorilla (unsigned long (*rng) (), void (*restart_rng)(), char *rngname);

void operm5 (unsigned long (*rng) (), char *rngname);

void binrnk (unsigned long (*rng) (), void restart_rng(), char *test, char *rngname);

void bitst (unsigned long (*rng) (), char *rngname);

void monky (unsigned long (*rng) (), void restart_rng(), char *test, char *rngname);

void cnt1s (unsigned long (*rng) (), void (*restart) (), char *test, char *rngname);

void park (unsigned long (*rng) (), char *rngname);

void mindist (unsigned long (*rng) (), char *rngname);

void sphere (unsigned long (*rng) (), char *rngname);

void squeez (unsigned long (*rng) (), char *rngname);

void osum (unsigned long (*rng) (), char *rngname);

void updown (unsigned long (*rng) (), char *rngname);

void craptest1 (unsigned long (*rng) (), char *rngname);

void craptest2 (unsigned long (*rng) (), char *rngname);


#endif /*_HEADER_H_*/



