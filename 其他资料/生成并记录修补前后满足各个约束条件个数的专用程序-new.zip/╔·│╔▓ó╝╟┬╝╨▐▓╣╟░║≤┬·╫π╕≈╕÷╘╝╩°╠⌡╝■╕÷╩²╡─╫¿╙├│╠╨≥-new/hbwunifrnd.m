function r = hbwunifrnd(a,b,m,n)

% Avoid    a+(b-a)*rand   in case   a-b > realmax
a2 = a/2;
b2 = b/2;
mu = a2+b2;
sig = b2-a2;

r = mu + sig .* (2*rand(m,n)-1);
